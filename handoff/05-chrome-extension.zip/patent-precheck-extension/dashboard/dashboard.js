// dashboard/dashboard.js — runs inside chrome-extension://... page

// ── Colour helpers ─────────────────────────────────────────────────────────
function scol(s) {
  return s >= 80 ? '#1D9E75' : s >= 60 ? '#378ADD' : s >= 40 ? '#EF9F27' : s > 0 ? '#E24B4A' : '#9ca3af';
}
function sband(s) {
  return s >= 80 ? 'File-ready' : s >= 60 ? 'Strong position' : s >= 40 ? 'Building strength' : s > 0 ? 'Not yet ready' : 'Not started';
}
function statusLabel(s) {
  if (s >= 80) return 'Ready to file — no action needed';
  if (s >= 60) return 'Mostly ready — minor gaps';
  if (s >= 40) return '1 area needs attention';
  if (s > 0)   return 'Critical areas of concern';
  return 'No data yet';
}

// ── Render helpers ─────────────────────────────────────────────────────────
function setText(id, val) {
  var el = document.getElementById(id);
  if (el) el.textContent = val;
}
function setColor(id, col) {
  var el = document.getElementById(id);
  if (el) el.style.color = col;
}
function setWidth(id, pct) {
  var el = document.getElementById(id);
  if (el) el.style.width = pct + '%';
}

// ── Render ─────────────────────────────────────────────────────────────────
function renderHero(score, journal) {
  var s = (score && score.overall) ? score.overall : 0;
  setText('overall-num', s > 0 ? s : '–');
  setColor('overall-num', scol(s));

  var atRisk = s >= 60 ? 'your position is solid' : s >= 40 ? 'some areas need strengthening' : s > 0 ? 'your score is in the critical zone' : '';
  var docNote = journal.length === 0
    ? 'No evidence saved yet — use the panel to log decisions and your idea moments.'
    : journal.length + ' piece' + (journal.length > 1 ? 's' : '') + ' of evidence saved.';

  setText('hero-summary-text', s > 0
    ? 'Your Patent PreCheck Score is ' + s + '/100 — ' + atRisk + '. ' + docNote
    : 'Start a conversation on any AI tool and your score will appear here in real time.');

  var pillsEl = document.getElementById('hero-pills');
  if (pillsEl && s > 0) {
    var html = '';
    if (s < 50) html += '<span class="pill pill-red">Score at high risk</span>';
    if (s >= 50 && s < 70) html += '<span class="pill pill-amber">Needs strengthening</span>';
    if (s >= 70) html += '<span class="pill pill-green">Strong position</span>';
    if (journal.length > 0) html += '<span class="pill pill-green">' + journal.length + ' evidence saved</span>';
    pillsEl.innerHTML = html;
  }
}

function renderAxes(score) {
  if (!score) return;
  var axes = [
    { key: 'conception',   color: '#0C447C' },
    { key: 'eligibility',  color: '#378ADD' },
    { key: 'documentation',color: '#1D9E75' },
  ];
  axes.forEach(function(a) {
    var val = score[a.key] || 0;
    setText('axis-' + a.key, val ? val + '/100' : '–');
    setColor('axis-' + a.key, val ? scol(val) : '#9ca3af');
    setWidth('axis-bar-' + a.key, val);
  });

  var c = score.conception || 0;
  setText('axis-note-conception', c >= 60
    ? c + '% — above the 60% target. Strong human contribution.'
    : c > 0
      ? c + '% — below the 60% target. More documented decisions will raise this.'
      : '50% of total score. Target: above 60% for a strong patent position.');
}

function renderFeatures(state) {
  var grid = document.getElementById('features-grid');
  if (!grid) return;

  var total  = state.turns  || 0;
  var human  = state.human  || 0;
  var ai     = total - human;
  var score  = state.score  || {};
  var tool   = state.tool   || 'AI Tool';

  if (total === 0) {
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:32px;color:#9ca3af;font-size:13px;background:#fff;border-radius:12px;border:0.5px solid #e5e7eb">Start a conversation on any AI tool to see your messages scored here.</div>';
    return;
  }

  var items = [
    { name: 'Your messages',              score: human,                  col: scol(score.conception || 0), note: human + ' human messages captured', pct: Math.min(100, human * 10) },
    { name: tool + ' responses',          score: ai,                     col: '#9ca3af',                   note: 'AI-generated — not counted toward your score', pct: Math.min(100, ai * 10) },
    { name: 'How much came from you',     score: score.conception || 0,  col: scol(score.conception || 0), note: 'How much came from you — 50% weight',           pct: score.conception || 0 },
    { name: 'Can it be patented?',score: score.eligibility || 0, col: scol(score.eligibility || 0),note: 'patentability estimate — 35% weight',         pct: score.eligibility || 0 },
    { name: 'How well documented',        score: score.documentation || 0, col: scol(score.documentation || 0), note: 'Evidence logged — 15% weight',              pct: score.documentation || 0 },
  ];

  grid.innerHTML = items.map(function(item) {
    return '<div class="feature-card">' +
      '<div class="fc-top">' +
        '<div class="fc-name">' + item.name + '</div>' +
        '<div class="fc-score" style="color:' + item.col + '">' + (item.score || '–') + '</div>' +
      '</div>' +
      '<div class="fc-bar-track"><div class="fc-bar-fill" style="width:' + (item.pct || 0) + '%;background:' + item.col + '"></div></div>' +
      '<div class="fc-status" style="color:' + item.col + '">' + item.note + '</div>' +
    '</div>';
  }).join('');
}

function renderJournal(entries) {
  var el = document.getElementById('journal-container');
  if (!el) return;

  if (!entries || entries.length === 0) {
    el.innerHTML = '<div class="journal-empty">No ideas logged yet. When a prompt appears in the panel, save your answer and it will appear here.</div>';
    return;
  }

  var catColors = {
    1: ['#E24B4A', '#FCEBEB'],
    2: ['#378ADD', '#E6F1FB'],
    3: ['#EF9F27', '#FAEEDA'],
    4: ['#1D9E75', '#EAF3DE'],
  };
  var catLabels  = { 1:'YOUR IDEA', 2:'AI INTERACTION', 3:'YOUR DECISION', 4:'ON RECORD' };
  var trigLabels = { conception:'Your idea', param:'AI suggested a value', strong:'Your own thinking', ratio:'Too much AI output', wrap:'Before you go' };

  var sorted = entries.slice().reverse();
  el.innerHTML = sorted.map(function(e) {
    var colors = catColors[e.category] || ['#9ca3af', '#f5f5f5'];
    var tc = colors[0], bg = colors[1];
    var time = e.timestamp ? new Date(e.timestamp).toLocaleString([], { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' }) : '';
    var label = catLabels[e.category] || 'NOTE';
    var trig  = trigLabels[e.trigger] || e.trigger || '';
    return '<div class="journal-entry">' +
      '<div class="je-top">' +
        '<span class="je-pill" style="background:' + bg + ';color:' + tc + '">' + label + '</span>' +
        '<span style="font-size:11px;color:#374151;font-weight:500">' + trig + '</span>' +
        '<span class="je-time">' + time + '</span>' +
      '</div>' +
      '<div class="je-answer">' + (e.answer || '') + '</div>' +
      '<div class="je-gain">+' + (e.scoreGain || 0) + ' pts · Saved from ' + (e.tool || 'AI Tool') + '</div>' +
    '</div>';
  }).join('');
}

function detectTool(url) {
  if (!url) return 'AI Tool';
  var u = url.toLowerCase();
  if (u.indexOf('claude.ai') >= 0)      return 'Claude';
  if (u.indexOf('chatgpt.com') >= 0)    return 'ChatGPT';
  if (u.indexOf('gemini.google') >= 0)  return 'Gemini';
  if (u.indexOf('perplexity.ai') >= 0)  return 'Perplexity';
  return 'AI Tool';
}

// ── Export ─────────────────────────────────────────────────────────────────
function exportReport() {
  chrome.storage.local.get(['ppc_score', 'ppc_journal'], function(res) {
    var score   = res.ppc_score   || {};
    var journal = res.ppc_journal || [];
    var date    = new Date().toLocaleString();
    var lines   = [
      'Patent PreCheck — Evidence Report',
      'Generated: ' + date,
      '',
      'Overall Patent PreCheck Score: ' + (score.overall || 0) + '/100',
      'Human Conception: ' + (score.conception || 0) + '/100',
      'Patent Eligibility: ' + (score.eligibility || 0) + '/100',
      'Documentation: ' + (score.documentation || 0) + '/100',
      '',
      '=== EVIDENCE JOURNAL ===',
      '',
    ];
    journal.forEach(function(e) {
      lines.push('[' + new Date(e.timestamp).toLocaleString() + '] ' + (e.trigger || '').toUpperCase() + ' (+' + e.scoreGain + ' pts)');
      lines.push(e.answer);
      lines.push('');
    });
    var blob = new Blob([lines.join('\n')], { type: 'text/plain' });
    var url  = URL.createObjectURL(blob);
    var a    = document.createElement('a');
    a.href = url;
    a.download = 'patent-precheck-report-' + Date.now() + '.txt';
    a.click();
    URL.revokeObjectURL(url);
  });
}

// ── Boot — wait for DOM then load storage ──────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {

  // Wire export button
  var exportBtn = document.getElementById('btn-export');
  if (exportBtn) exportBtn.addEventListener('click', exportReport);

  // Load from storage first
  chrome.storage.local.get(['ppc_score', 'ppc_journal', 'ppc_journal_entries'], function(res) {
    var score   = res.ppc_score || { overall:0, conception:0, eligibility:0, documentation:10 };
    var journal = res.ppc_journal || res.ppc_journal_entries || [];

    renderHero(score, journal);
    renderAxes(score);
    renderJournal(journal);

    // Then try to get live data from active tab
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, function(tabs) {
      if (!tabs || !tabs[0]) return;
      var tab = tabs[0];
      var toolName = detectTool(tab.url);
      setText('nav-tool', toolName);
      setText('nav-session', 'Active on ' + toolName);

      chrome.tabs.sendMessage(tab.id, { type: 'GET_STATE' }, function(state) {
        if (chrome.runtime.lastError || !state) return;
        if (state.score) {
          renderHero(state.score, journal);
          renderAxes(state.score);
        }
        if (state.tool) setText('nav-tool', state.tool);
        renderFeatures(state);
      });
    });
  });

  // Live storage updates
  chrome.storage.onChanged.addListener(function(changes) {
    chrome.storage.local.get(['ppc_score', 'ppc_journal'], function(res) {
      var score   = res.ppc_score   || {};
      var journal = res.ppc_journal || [];
      renderHero(score, journal);
      renderAxes(score);
      renderJournal(journal);
    });
  });
});

// ── Extension Document Analyzer ─────────────────────────────────────────────
var extFileContent = '';
var extFileName = '';

function switchTab(name) {
  document.querySelectorAll('.dash-tab').forEach(function(t) { t.classList.remove('active'); });
  document.querySelectorAll('.dash-pane').forEach(function(p) { p.classList.remove('active'); });
  document.getElementById('pane-' + name).classList.add('active');
  event.target.classList.add('active');
  // Load journal into journal tab
  if (name === 'journal') loadJournalTab();
}

function loadJournalTab() {
  chrome.storage.local.get(['ppc_journal'], function(res) {
    var entries = res.ppc_journal || [];
    var container = document.getElementById('journal-container-tab');
    if (!entries.length) {
      container.innerHTML = '<div style="background:#fff;border:0.5px solid #e5e7eb;border-radius:12px;padding:28px;text-align:center;color:#9ca3af;font-size:13px">No evidence saved yet. When a hygiene check fires in the panel, save your answer and it will appear here.</div>';
      return;
    }
    container.innerHTML = entries.map(function(e) {
      return '<div style="background:#fff;border:0.5px solid #e5e7eb;border-radius:10px;padding:14px 16px;margin-bottom:8px"><div style="font-size:11px;color:#9ca3af;margin-bottom:6px">' + (e.date || '') + ' · ' + (e.type || '') + '</div><div style="font-size:13px;color:#374151;line-height:1.6">' + (e.text || e.answer || '') + '</div></div>';
    }).join('');
  });
}

// Drop zone
var extDrop = document.getElementById('ext-drop-zone');
if (extDrop) {
  extDrop.addEventListener('dragover', function(e) { e.preventDefault(); extDrop.classList.add('dragover'); });
  extDrop.addEventListener('dragleave', function() { extDrop.classList.remove('dragover'); });
  extDrop.addEventListener('drop', function(e) {
    e.preventDefault();
    extDrop.classList.remove('dragover');
    var file = e.dataTransfer.files[0];
    if (file) extHandleFile(file);
  });
}
var extFileInput = document.getElementById('ext-file-input');
if (extFileInput) {
  extFileInput.addEventListener('change', function() {
    if (this.files[0]) extHandleFile(this.files[0]);
  });
}
var extFileClear = document.getElementById('ext-file-clear');
if (extFileClear) {
  extFileClear.addEventListener('click', function() {
    extFileContent = ''; extFileName = '';
    document.getElementById('ext-file-preview').style.display = 'none';
    extFileInput.value = '';
    extUpdateBtn();
  });
}

function extHandleFile(file) {
  extFileName = file.name;
  var reader = new FileReader();
  reader.onload = function(e) {
    extFileContent = (e.target.result || '').slice(0, 80000);
    document.getElementById('ext-file-name').textContent = file.name;
    document.getElementById('ext-file-size').textContent = (file.size / 1024).toFixed(1) + ' KB';
    document.getElementById('ext-file-preview').style.display = 'flex';
    extUpdateBtn();
  };
  reader.readAsText(file);
}

var extPaste = document.getElementById('ext-paste');
var extContext = document.getElementById('ext-context');
if (extPaste) extPaste.addEventListener('input', extUpdateBtn);

function extUpdateBtn() {
  var has = extFileContent.trim().length > 20 || (extPaste && extPaste.value.trim().length > 20);
  var btn = document.getElementById('ext-analyze-btn');
  if (btn) btn.disabled = !has;
}

var extAnalyzeBtn = document.getElementById('ext-analyze-btn');
if (extAnalyzeBtn) {
  extAnalyzeBtn.addEventListener('click', extAnalyze);
}

async function extAnalyze() {
  var content = extFileContent || (extPaste ? extPaste.value : '');
  var context = extContext ? extContext.value : '';
  if (!content.trim()) return;

  document.getElementById('ext-analyze-btn').disabled = true;
  document.getElementById('ext-error').style.display = 'none';
  document.getElementById('ext-result').style.display = 'none';
  document.getElementById('ext-loading').style.display = 'block';

  var prompt = 'You are the Patent PreCheck AI. Analyze this work and return ONLY a JSON object (no markdown):\n\n' +
    (context ? 'User context: ' + context + '\n\n' : '') +
    'CONTENT:\n' + content.slice(0, 35000) + '\n\n' +
    'Return: {"score":<0-100>,"conception":<0-100>,"eligibility":<0-100>,"documentation":<0-100>,"band":"<Not yet ready|Building strength|Strong position|File-ready>","summary":"<2-3 sentences>","human_contributions":["<item>","<item>","<item>"],"ai_or_common":["<item>","<item>"],"recommendations":[{"title":"<action>","detail":"<why/how>","priority":"high|medium|low"},{"title":"<action>","detail":"<why/how>","priority":"high|medium|low"},{"title":"<action>","detail":"<why/how>","priority":"high|medium|low"}]}';

  try {
    var res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: 'claude-sonnet-4-20250514', max_tokens: 1000, messages: [{ role: 'user', content: prompt }] })
    });
    var data = await res.json();
    if (!res.ok) throw new Error(data.error?.message || 'API error');
    var text = data.content[0].text.trim().replace(/^```json\n?/, '').replace(/\n?```$/, '');
    var r = JSON.parse(text);
    extShowResult(r);
  } catch(err) {
    document.getElementById('ext-loading').style.display = 'none';
    document.getElementById('ext-error').style.display = 'block';
    document.getElementById('ext-error').textContent = 'Analysis failed: ' + (err.message || 'Please try again.');
    document.getElementById('ext-analyze-btn').disabled = false;
  }
}

function extScol(s) {
  return s >= 80 ? '#1D9E75' : s >= 60 ? '#378ADD' : s >= 40 ? '#EF9F27' : '#E24B4A';
}

function extShowResult(r) {
  document.getElementById('ext-loading').style.display = 'none';
  var score = Math.max(0, Math.min(100, r.score || 0));
  var col = extScol(score);

  var html = '<div class="analyzer-result">' +
    '<div class="analyzer-score-row">' +
      '<div class="analyzer-score-circle" style="border-color:' + col + '">' +
        '<div class="analyzer-score-num" style="color:' + col + '">' + score + '</div>' +
        '<div class="analyzer-score-label">Score</div>' +
      '</div>' +
      '<div>' +
        '<div class="analyzer-band" style="color:' + col + '">' + (r.band || '') + '</div>' +
        '<div class="analyzer-summary">' + (r.summary || '') + '</div>' +
      '</div>' +
    '</div>' +
    '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:18px">' +
      '<div style="background:#f9fafb;border-radius:8px;padding:10px;text-align:center"><div style="font-size:18px;font-weight:700;color:' + extScol(r.conception) + '">' + (r.conception||'–') + '</div><div style="font-size:10px;color:#9ca3af;margin-top:2px">How much is yours</div></div>' +
      '<div style="background:#f9fafb;border-radius:8px;padding:10px;text-align:center"><div style="font-size:18px;font-weight:700;color:' + extScol(r.eligibility) + '">' + (r.eligibility||'–') + '</div><div style="font-size:10px;color:#9ca3af;margin-top:2px">Can it be patented?</div></div>' +
      '<div style="background:#f9fafb;border-radius:8px;padding:10px;text-align:center"><div style="font-size:18px;font-weight:700;color:' + extScol(r.documentation) + '">' + (r.documentation||'–') + '</div><div style="font-size:10px;color:#9ca3af;margin-top:2px">How well documented</div></div>' +
    '</div>';

  if (r.human_contributions && r.human_contributions.length) {
    html += '<div class="analyzer-section"><h4>✅ What appears to be yours</h4>';
    r.human_contributions.forEach(function(i) { html += '<div class="analyzer-item"><div class="analyzer-dot" style="background:#1D9E75"></div>' + i + '</div>'; });
    html += '</div>';
  }
  if (r.ai_or_common && r.ai_or_common.length) {
    html += '<div class="analyzer-section"><h4>🤖 What may have come from AI / common knowledge</h4>';
    r.ai_or_common.forEach(function(i) { html += '<div class="analyzer-item"><div class="analyzer-dot" style="background:#9ca3af"></div>' + i + '</div>'; });
    html += '</div>';
  }
  if (r.recommendations && r.recommendations.length) {
    html += '<div class="analyzer-section"><h4>What to do next</h4>';
    r.recommendations.forEach(function(rec) {
      var pc = rec.priority === 'high' ? '#FFF5F5:#E24B4A' : rec.priority === 'medium' ? '#FFFBEB:#D97706' : '#F0FFF4:#1D9E75';
      var p = pc.split(':');
      html += '<div class="analyzer-rec" style="border-left:3px solid ' + p[1] + '"><h5>' + rec.title + '</h5><p>' + rec.detail + '</p></div>';
    });
    html += '</div>';
  }

  html += '<button onclick="this.parentElement.parentElement.remove();document.getElementById(\'ext-analyze-btn\').disabled=false" style="margin-top:16px;background:none;border:1.5px solid #e5e7eb;border-radius:8px;padding:8px 16px;font-size:12px;cursor:pointer;color:#6b7280;font-family:inherit">← Analyze something else</button>';
  html += '</div>';

  document.getElementById('ext-result').innerHTML = html;
  document.getElementById('ext-result').style.display = 'block';
}
