// ── State ──────────────────────────────────────────────────────────────────
var currentStep = 0;
var formData = {};
var STEPS = 6;

// ── Disclaimer ────────────────────────────────────────────────────────────
function onDiscCheck(cb) {
  var row = document.getElementById('chk-row');
  var btn = document.getElementById('btn-go');
  row.classList.toggle('on', cb.checked);
  btn.classList.toggle('on', cb.checked);
  btn.disabled = !cb.checked;
  // Make the transition unmistakable
  if (cb.checked) {
    btn.textContent = 'I understand — let\'s file →';
    btn.style.transform = 'scale(1.02)';
    setTimeout(function() { btn.style.transform = ''; }, 200);
  } else {
    btn.textContent = 'I understand — let\'s file →';
  }
}

function startWizard() {
  if (!document.getElementById('disc-chk').checked) return;
  chrome.storage.local.set({ ppc_cr_disclaimer: Date.now() });
  document.getElementById('overlay').style.display = 'none';
  // Load saved progress
  chrome.storage.local.get(['ppc_cr_form', 'ppc_score', 'ppc_journal'], function(res) {
    if (res.ppc_cr_form && Object.keys(res.ppc_cr_form).length > 0) {
      formData = res.ppc_cr_form;
      restoreForm();
      // Show resume banner
      var rb = document.getElementById('resume-banner');
      var rbb = document.getElementById('btn-resume');
      if (rb) rb.style.display = 'flex';
      if (rbb) rbb.style.display = 'block';
    }
    // Pre-fill from session
    if (!formData['f-year']) setField('f-year', new Date().getFullYear());
    if (!formData['f-worktype']) setField('f-worktype', 'Literary Work');
    if (!formData['f-published']) setField('f-published', 'No');
    if (!formData['f-forhire']) setField('f-forhire', 'No');
    if (!formData['f-transfer']) setField('f-transfer', 'none');
    if (!formData['f-domicile']) setField('f-domicile', 'United States');
    showPg('pg-intro');
  });
}

function goBack() {
  window.history.back();
}

// ── Page routing ──────────────────────────────────────────────────────────
function showPg(id) {
  ['pg-intro','pg-wizard','pg-complete'].forEach(function(p) {
    document.getElementById(p).style.display = p === id ? 'block' : 'none';
  });
  window.scrollTo(0,0);
}

// ── Step navigation ───────────────────────────────────────────────────────
function goStep(n) {
  currentStep = n;
  // Hide all steps
  for (var i = 1; i <= STEPS; i++) {
    var el = document.getElementById('s' + i);
    if (el) el.style.display = i === n ? 'block' : 'none';
  }
  // Update progress
  var pct = Math.round(((n - 1) / STEPS) * 100);
  document.getElementById('progress-fill').style.width = pct + '%';
  document.getElementById('step-pct').textContent = pct + '%';
  document.getElementById('step-title').textContent = 'Step ' + n + ' of ' + STEPS;
  // Update circles
  for (var i = 1; i <= STEPS; i++) {
    var sc = document.getElementById('sc-' + i);
    var sl = document.getElementById('sl-' + i);
    sc.className = 'step-circle' + (i < n ? ' done' : i === n ? ' active' : '');
    sl.className = 'step-lbl' + (i < n ? ' done' : i === n ? ' active' : '');
    if (i < STEPS) {
      var ln = document.getElementById('ln-' + i);
      ln.className = 'step-line' + (i < n ? ' done' : '');
    }
  }
  if (n === 6) buildReview();
  showPg('pg-wizard');
  window.scrollTo(0,0);
}

// ── Account confirm ───────────────────────────────────────────────────────
function toggleAcct() {
  var chk = document.getElementById('acct-chk');
  var row = document.getElementById('acct-confirm');
  var btn = document.getElementById('s1-next');
  chk.checked = !chk.checked;
  row.classList.toggle('on', chk.checked);
  btn.disabled = !chk.checked;
}

// ── Pub change ────────────────────────────────────────────────────────────
function onPubChange() {
  var v = document.getElementById('f-published').value;
  document.getElementById('pub-fields').style.display = v === 'Yes' ? 'block' : 'none';
}

function onTransferChange() {}

// ── Deposit selection ─────────────────────────────────────────────────────
function selectDeposit(n) {
  [1, 2].forEach(function(i) {
    document.getElementById('dep-opt-' + i).classList.toggle('on', i === n);
  });
  formData['deposit-type'] = n;
}

// ── Save to storage ───────────────────────────────────────────────────────
function save() {
  var ids = ['f-worktype','f-title','f-published','f-pubdate','f-pubnation','f-year','f-author','f-domicile','f-birthyear','f-forhire','f-authorship','f-claimant','f-claimant-address','f-transfer','f-confirmation'];
  ids.forEach(function(id) {
    var el = document.getElementById(id);
    if (el) formData[id] = el.value;
  });
  chrome.storage.local.set({ ppc_cr_form: formData });
  // Update the in-wizard save time
  var st = document.getElementById('save-time');
  if (st) {
    var now = new Date();
    st.textContent = 'Last saved ' + now.toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'});
  }
  var ind = document.getElementById('save-ind');
  ind.classList.add('show');
  setTimeout(function() { ind.classList.remove('show'); }, 1500);
}

function resumeProgress() {
  // Find the highest step that has data and go there
  var step = 1;
  if (formData['f-worktype'] || formData['f-title']) step = 2;
  if (formData['f-published'] !== undefined && formData['f-year']) step = 3;
  if (formData['f-author']) step = 4;
  if (formData['f-claimant']) step = 5;
  if (formData['f-confirmation']) step = 6;
  goStep(step);
}

function restoreForm() {
  Object.keys(formData).forEach(function(id) {
    var el = document.getElementById(id);
    if (el) el.value = formData[id];
  });
  onPubChange();
}

function setField(id, val) {
  var el = document.getElementById(id);
  if (el && !el.value) el.value = val;
}

// ── Review ────────────────────────────────────────────────────────────────
function buildReview() {
  save();
  var sections = [
    { title: 'Type of work', rows: [
      { label: 'Type of Work', id: 'f-worktype' },
      { label: 'Title of Work', id: 'f-title' },
    ]},
    { title: 'Publication', rows: [
      { label: 'Published?', id: 'f-published' },
      { label: 'Year of Completion', id: 'f-year' },
      { label: 'Date of Publication', id: 'f-pubdate' },
    ]},
    { title: 'Author', rows: [
      { label: 'Author Name', id: 'f-author' },
      { label: 'Domicile', id: 'f-domicile' },
      { label: 'Year of Birth', id: 'f-birthyear' },
      { label: 'Work for Hire', id: 'f-forhire' },
      { label: 'Nature of Authorship', id: 'f-authorship' },
    ]},
    { title: 'Claimant', rows: [
      { label: 'Claimant', id: 'f-claimant' },
      { label: 'Address', id: 'f-claimant-address' },
      { label: 'Transfer', id: 'f-transfer' },
    ]},
  ];

  var html = '';
  sections.forEach(function(sec) {
    html += '<div class="review-section"><div class="review-section-title">' + sec.title + '</div>';
    sec.rows.forEach(function(r) {
      var val = formData[r.id] || '';
      html += '<div class="review-row"><div class="review-label">' + r.label + '</div><div class="review-value' + (val ? '' : ' empty') + '">' + (val || 'Not filled in — go back and complete') + '</div></div>';
    });
    html += '</div>';
  });
  document.getElementById('review-content').innerHTML = html;
}

// ── Copy blocks ───────────────────────────────────────────────────────────
function copyBlock(id, btn) {
  var text = document.getElementById(id).textContent;
  navigator.clipboard.writeText(text).then(function() {
    btn.textContent = 'Copied ✓';
    btn.classList.add('copied');
    setTimeout(function() { btn.textContent = 'Copy'; btn.classList.remove('copied'); }, 2000);
  });
}

// ── Complete ──────────────────────────────────────────────────────────────
function completeFiling() {
  save();
  // Save to evidence journal
  chrome.storage.local.get(['ppc_journal'], function(res) {
    var j = res.ppc_journal || [];
    j.push({
      id: 'cr-' + Date.now(),
      timestamp: Date.now(),
      category: 4,
      trigger: 'copyright_registration',
      answer: 'Copyright registration filed with US Copyright Office for "' + (formData['f-title'] || 'Patent PreCheck') + '". Service request: ' + (formData['f-confirmation'] || 'pending') + '. Filed: ' + new Date().toLocaleDateString() + '.',
      scoreGain: 20,
      tool: 'Patent PreCheck Filing Wizard',
      url: window.location.href,
    });
    chrome.storage.local.set({ ppc_journal: j, ppc_cr_complete: Date.now() });
  });
  showPg('pg-complete');
}

function downloadSummary() {
  var lines = [
    'Patent PreCheck — Copyright Registration Summary',
    'Generated: ' + new Date().toLocaleString(),
    '',
    'FILED WITH: US Copyright Office (copyright.gov eCO)',
    'EFFECTIVE DATE: ' + new Date().toLocaleDateString(),
    '',
    '=== APPLICATION DETAILS ===',
    '',
    'Type of Work: '       + (formData['f-worktype'] || ''),
    'Title: '              + (formData['f-title'] || ''),
    'Year of Completion: ' + (formData['f-year'] || ''),
    'Published: '          + (formData['f-published'] || ''),
    '',
    'Author: '             + (formData['f-author'] || ''),
    'Domicile: '           + (formData['f-domicile'] || ''),
    'Work for Hire: '      + (formData['f-forhire'] || ''),
    'Nature of Authorship: ' + (formData['f-authorship'] || ''),
    '',
    'Claimant: '           + (formData['f-claimant'] || ''),
    'Address: '            + (formData['f-claimant-address'] || ''),
    '',
    'Service Request #: '  + (formData['f-confirmation'] || 'Not yet entered'),
    '',
    '---',
    'Prepared with Patent PreCheck · patentprecheck.com',
    'Patent PreCheck is not a law firm and does not provide legal advice.',
  ];
  var blob = new Blob([lines.join('\n')], { type: 'text/plain' });
  var url = URL.createObjectURL(blob);
  var a = document.createElement('a');
  a.href = url;
  a.download = 'patent-precheck-copyright-' + Date.now() + '.txt';
  a.click();
  URL.revokeObjectURL(url);
}

// ── Gentle leave reminder ────────────────────────────────────────────────
window.addEventListener('beforeunload', function(e) {
  // Only show if mid-wizard and has unsaved data
  if (currentStep > 0 && Object.keys(formData).length > 0) {
    // Modern browsers show their own generic message — we just trigger it
    e.preventDefault();
    e.returnValue = '';
  }
});

// ── Boot ──────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  // Check if disclaimer already accepted this session
  chrome.storage.local.get(['ppc_cr_disclaimer'], function(res) {
    if (res.ppc_cr_disclaimer) {
      // Accepted recently — check if within last 24h
      var age = Date.now() - (res.ppc_cr_disclaimer || 0);
      if (age < 24 * 60 * 60 * 1000) {
        // Skip disclaimer, go straight to wizard
        document.getElementById('overlay').style.display = 'none';
        startWizard();
        return;
      }
    }
    // Show disclaimer
    document.getElementById('overlay').style.display = 'flex';
  });
});

// ── Wire all event listeners (replaces inline handlers removed for CSP) ───
document.addEventListener('DOMContentLoaded', function() {
  function on(id, evt, fn) {
    var el = document.getElementById(id);
    if (el) el.addEventListener(evt, fn);
  }
  function onAll(sel, evt, fn) {
    document.querySelectorAll(sel).forEach(function(el) { el.addEventListener(evt, fn); });
  }

  // Disclaimer
  on('chk-row', 'click', function() {
    var c = document.getElementById('disc-chk');
    setTimeout(function() { onDiscCheck(c); }, 10);
  });
  on('disc-chk', 'change', function() { onDiscCheck(this); });
  on('btn-go', 'click', startWizard);
  on('btn-resume', 'click', resumeProgress);

  // Account step
  on('acct-confirm', 'click', toggleAcct);
  on('acct-chk', 'click', function(e) { e.stopPropagation(); });
  on('s1-next', 'click', function() { goStep(2); });

  // Step 2 — work type
  on('f-worktype', 'change', save);
  on('f-title', 'change', save);
  on('f-title', 'input', save);

  // Step 3 — publication
  on('f-published', 'change', function() { onPubChange(); save(); });
  on('f-pubdate', 'change', save);
  on('f-pubnation', 'change', save);
  on('f-year', 'change', save);
  on('f-year', 'input', save);

  // Step 4 — authorship
  on('f-author', 'change', save);
  on('f-author', 'input', save);
  on('f-domicile', 'change', save);
  on('f-domicile', 'input', save);
  on('f-birthyear', 'change', save);
  on('f-birthyear', 'input', save);
  on('f-forhire', 'change', save);
  on('f-authorship', 'change', save);
  on('f-authorship', 'input', save);

  // Step 5 — claimant & deposit
  on('f-claimant', 'change', save);
  on('f-claimant', 'input', save);
  on('f-claimant-address', 'change', save);
  on('f-claimant-address', 'input', save);
  on('f-transfer', 'change', function() { onTransferChange(); save(); });
  on('dep-opt-1', 'click', function() { selectDeposit(1); });
  on('dep-opt-2', 'click', function() { selectDeposit(2); });

  // Step 6 — confirmation
  on('f-confirmation', 'change', save);
  on('f-confirmation', 'input', save);

  // Intro start button
  on('btn-start-main', 'click', function() { goStep(1); });

  // Step nav buttons — wire by class since they're dynamic
  // (goStep calls are in renderStep which re-creates DOM, so we use event delegation)
  document.addEventListener('click', function(e) {
    var btn = e.target.closest('[data-step]');
    if (btn) {
      var step = parseInt(btn.getAttribute('data-step'));
      if (!isNaN(step)) goStep(step);
    }
    var copyBtn = e.target.closest('[data-copy]');
    if (copyBtn) {
      var srcId = copyBtn.getAttribute('data-copy');
      copyBlock(srcId, copyBtn);
    }
  });
});
