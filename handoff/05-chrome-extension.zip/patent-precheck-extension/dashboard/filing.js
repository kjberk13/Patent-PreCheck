// dashboard/filing.js

var filingType = null;
var sessionData = { score: {}, journal: [], turns: 0, tool: 'AI Tool' };

// ── Disclaimer ─────────────────────────────────────────────────────────────
function onCheck(checkbox) {
  var row = document.getElementById('checkbox-row');
  var btn = document.getElementById('btn-proceed');
  if (checkbox.checked) {
    row.classList.add('checked');
    btn.classList.add('active');
    btn.disabled = false;
  } else {
    row.classList.remove('checked');
    btn.classList.remove('active');
    btn.disabled = true;
  }
}

function proceedFromDisclaimer() {
  var checked = document.getElementById('disclaimer-check').checked;
  if (!checked) return;
  // Record that disclaimer was accepted with timestamp
  chrome.storage.local.set({ ppc_disclaimer_accepted: Date.now() });
  document.getElementById('disclaimer-overlay').style.display = 'none';
  showPage('page-choose');
}

// ── Page routing ───────────────────────────────────────────────────────────
function showPage(id) {
  var pages = ['page-choose', 'page-copyright', 'page-provisional', 'page-complete'];
  pages.forEach(function(p) {
    var el = document.getElementById(p);
    if (el) el.classList.toggle('page-hidden', p !== id);
  });
  window.scrollTo(0, 0);
}

function startFiling(type) {
  filingType = type;
  if (type === 'copyright') {
    showPage('page-copyright');
    prefillCopyright();
  } else {
    showPage('page-provisional');
    prefillProvisional();
  }
}

function showHelp() { toggleHelp(); }

function toggleHelp() {
  var panel = document.getElementById('help-panel');
  if (!panel) return;
  var open = panel.style.display !== 'none';
  panel.style.display = open ? 'none' : 'block';
  // Scroll into view if opening
  if (!open) setTimeout(function() { panel.scrollIntoView({ behavior:'smooth', block:'nearest' }); }, 50);
}

// ── Account checkbox helper ────────────────────────────────────────────────
function toggleAccountDone(rowId, checkId, nextId) {
  var row   = document.getElementById(rowId);
  var check = document.getElementById(checkId);
  var next  = document.getElementById(nextId);
  check.checked = !check.checked;
  if (check.checked) {
    row.classList.add('checked-row');
    if (next) { next.disabled = false; next.style.opacity = '1'; }
  } else {
    row.classList.remove('checked-row');
    if (next) { next.disabled = true; next.style.opacity = '0.4'; }
  }
}

// ── Copyright step navigation ──────────────────────────────────────────────
function crStep(n) {
  [1, 2, 3, 4].forEach(function(i) {
    var el = document.getElementById('cr-step-' + i);
    if (el) el.style.display = i === n ? 'block' : 'none';
    var dot = document.getElementById('cr-dot-' + i);
    if (dot) {
      dot.classList.remove('active', 'done');
      if (i < n) dot.classList.add('done');
      if (i === n) dot.classList.add('active');
    }
    var label = document.getElementById('cr-label-' + i);
    if (label) {
      label.classList.remove('active', 'done');
      if (i < n) label.classList.add('done');
      if (i === n) label.classList.add('active');
    }
    if (i < 4) {
      var line = document.getElementById('cr-line-' + i);
      if (line) line.classList.toggle('done', i < n);
    }
  });
  if (n === 4) buildCrSummary();
  window.scrollTo(0, 0);
}

function buildCrSummary() {
  var title       = val('cr-title');
  var workType    = val('cr-work-type');
  var year        = val('cr-year');
  var description = val('cr-description');
  var author      = val('cr-author');
  var authorship  = val('cr-authorship');
  var claimant    = val('cr-claimant');
  var el = document.getElementById('cr-summary-content');
  if (el) {
    el.innerHTML =
      row('Type of Work', workType) +
      row('Title', title) +
      row('Year of Completion', year) +
      row('Description', description) +
      row('Author', author) +
      row('Nature of Authorship', authorship) +
      row('Copyright Claimant', claimant);
  }
}

// ── Provisional step navigation ────────────────────────────────────────────
function prStep(n) {
  [1, 2, 3, 4, 5].forEach(function(i) {
    var el = document.getElementById('pr-step-' + i);
    if (el) el.style.display = i === n ? 'block' : 'none';
    var dot = document.getElementById('pr-dot-' + i);
    if (dot) {
      dot.classList.remove('active', 'done');
      if (i < n) dot.classList.add('done');
      if (i === n) dot.classList.add('active');
    }
    var label = document.getElementById('pr-label-' + i);
    if (label) {
      label.classList.remove('active', 'done');
      if (i < n) label.classList.add('done');
      if (i === n) label.classList.add('active');
    }
    if (i < 5) {
      var line = document.getElementById('pr-line-' + i);
      if (line) line.classList.toggle('done', i < n);
    }
  });
  if (n === 4) buildProvisionalDoc();
  window.scrollTo(0, 0);
}

function buildProvisionalDoc() {
  var title    = val('pr-title');
  var field    = val('pr-field');
  var bg       = val('pr-background');
  var summary  = val('pr-summary');
  var inventor = val('pr-inventor-name');
  var city     = val('pr-inventor-city');
  var address  = val('pr-inventor-address');
  var date     = new Date().toLocaleDateString('en-US', { year:'numeric', month:'long', day:'numeric' });

  var doc =
    'PROVISIONAL PATENT APPLICATION\n' +
    '================================\n\n' +
    'Title: ' + (title || '[Title of Invention]') + '\n' +
    'Date Prepared: ' + date + '\n' +
    'Inventor(s): ' + (inventor || '[Inventor Name]') + '\n' +
    'Residence: ' + (city || '[City, State, Country]') + '\n\n' +
    '1. FIELD OF THE INVENTION\n' +
    '--------------------------\n' +
    (field || '[Describe the technical field this invention belongs to]') + '\n\n' +
    '2. BACKGROUND\n' +
    '--------------\n' +
    (bg || '[Describe the problem that existed before this invention and why existing approaches were inadequate]') + '\n\n' +
    '3. SUMMARY OF THE INVENTION\n' +
    '----------------------------\n' +
    (summary || '[Describe your invention — what it does, how it works, and what makes it new and useful]') + '\n\n' +
    '4. DETAILED DESCRIPTION\n' +
    '------------------------\n' +
    'The invention described herein was conceived by ' + (inventor || '[Inventor]') +
    ' independently, using AI tools as assistants only. The following is a detailed description of the preferred embodiment:\n\n' +
    (summary || '') + '\n\n' +
    '5. INVENTOR DECLARATION\n' +
    '------------------------\n' +
    'I, ' + (inventor || '[Inventor Name]') + ', residing at ' + (address || '[Address]') + ', ' +
    'hereby declare that I am the original inventor of the invention described herein. ' +
    'I believe the foregoing information to be true and correct.\n\n' +
    'Signature: ___________________________\n' +
    'Date: ' + date + '\n\n' +
    '--- END OF PROVISIONAL APPLICATION ---\n' +
    '\nPrepared with Patent PreCheck · patentprecheck.com\n' +
    'Patent PreCheck is not a law firm and does not provide legal advice.\n' +
    'Review all content carefully before filing.';

  var el = document.getElementById('pr-doc-preview');
  if (el) el.textContent = doc;
  window._provisionalDoc = doc;
  window._provisionalTitle = title;
}

function downloadProvisional() {
  var doc   = window._provisionalDoc || 'No document generated yet.';
  var title = (window._provisionalTitle || 'provisional-patent').replace(/[^a-z0-9]/gi, '-').toLowerCase();
  var blob  = new Blob([doc], { type: 'text/plain' });
  var url   = URL.createObjectURL(blob);
  var a     = document.createElement('a');
  a.href     = url;
  a.download = 'patent-precheck-' + title + '-provisional.txt';
  a.click();
  URL.revokeObjectURL(url);
}

// ── Complete filing ────────────────────────────────────────────────────────
function completeFiling(type) {
  var sub = document.getElementById('complete-sub');
  if (sub) {
    sub.textContent = type === 'copyright'
      ? 'Your copyright application is in. Save the confirmation number from copyright.gov. Your eCO number confirms your effective registration date.'
      : 'Your provisional patent is filed. Save your USPTO Application Number — that date is your legal patent priority date. You have 12 months to file a full utility patent.';
  }
  // Save to journal
  chrome.storage.local.get(['ppc_journal'], function(res) {
    var journal = res.ppc_journal || [];
    journal.push({
      id:        'filing-' + Date.now(),
      timestamp: Date.now(),
      category:  4,
      trigger:   type === 'copyright' ? 'copyright_filing' : 'provisional_filing',
      answer:    type === 'copyright'
        ? 'Copyright application filed via Patent PreCheck filing assistant on ' + new Date().toLocaleDateString()
        : 'Provisional patent application filed via Patent PreCheck filing assistant on ' + new Date().toLocaleDateString(),
      scoreGain: 20,
      tool:      'Patent PreCheck Filing',
      url:       window.location.href,
    });
    chrome.storage.local.set({ ppc_journal: journal });
  });
  showPage('page-complete');
}

function downloadSummary() {
  var lines = [
    'Patent PreCheck — Filing Summary',
    'Generated: ' + new Date().toLocaleString(),
    '',
    'Filing type: ' + (filingType === 'copyright' ? 'Copyright Registration (copyright.gov)' : 'Provisional Patent Application (USPTO)'),
    '',
  ];
  if (filingType === 'copyright') {
    lines.push('Title: ' + val('cr-title'));
    lines.push('Type: '  + val('cr-work-type'));
    lines.push('Year: '  + val('cr-year'));
    lines.push('Author: ' + val('cr-author'));
    lines.push('Claimant: ' + val('cr-claimant'));
  } else {
    lines.push('Title: '    + val('pr-title'));
    lines.push('Inventor: ' + val('pr-inventor-name'));
    lines.push('Address: '  + val('pr-inventor-address'));
    if (window._provisionalDoc) {
      lines.push('');
      lines.push('=== FULL APPLICATION TEXT ===');
      lines.push('');
      lines.push(window._provisionalDoc);
    }
  }
  var blob = new Blob([lines.join('\n')], { type: 'text/plain' });
  var url  = URL.createObjectURL(blob);
  var a    = document.createElement('a');
  a.href     = url;
  a.download = 'patent-precheck-filing-summary-' + Date.now() + '.txt';
  a.click();
  URL.revokeObjectURL(url);
}

// ── Pre-fill from session data ─────────────────────────────────────────────
function prefillCopyright() {
  var d = sessionData;
  setVal('cr-year', new Date().getFullYear());
  if (d.sessionTitle) setVal('cr-title', d.sessionTitle);
  if (d.description)  setVal('cr-description', d.description);
}

function prefillProvisional() {
  var d = sessionData;
  if (d.sessionTitle) setVal('pr-title', 'System and Method for ' + d.sessionTitle);
  if (d.background)   setVal('pr-background', d.background);
  if (d.summary)      setVal('pr-summary', d.summary);
  if (d.fieldText)    setVal('pr-field', d.fieldText);
}

// ── Helpers ────────────────────────────────────────────────────────────────
function val(id) {
  var el = document.getElementById(id);
  return el ? el.value.trim() : '';
}
function setVal(id, v) {
  var el = document.getElementById(id);
  if (el && !el.value) el.value = v;
}
function row(label, value) {
  return '<div style="margin-bottom:7px"><span style="font-size:10px;font-weight:700;color:#9ca3af;text-transform:uppercase;letter-spacing:.05em">' +
    label + '</span><div style="font-size:12px;color:#111;margin-top:2px">' + (value || '<em style="color:#9ca3af">Not filled in</em>') + '</div></div>';
}

// ── Boot ───────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  // Load session data to use for pre-fill
  chrome.storage.local.get(['ppc_score', 'ppc_journal', 'ppc_session_title', 'ppc_disclaimer_accepted'], function(res) {
    var score   = res.ppc_score   || {};
    var journal = res.ppc_journal || [];

    // Build pre-fill data from journal entries
    var conceptionEntries = journal.filter(function(e) { return e.trigger === 'conception' || e.trigger === 'strong'; });
    var wrapEntry         = journal.find(function(e)  { return e.trigger === 'wrap'; });

    sessionData.score        = score;
    sessionData.journal      = journal;
    sessionData.sessionTitle = res.ppc_session_title || '';
    sessionData.description  = conceptionEntries.map(function(e) { return e.answer; }).join('\n\n') || '';
    sessionData.summary      = wrapEntry ? wrapEntry.answer : (conceptionEntries.length ? conceptionEntries[0].answer : '');
    sessionData.background   = '';
    sessionData.fieldText    = '';

    // Try to get live data from the active AI tool tab
    chrome.tabs.query({ active: true, lastFocusedWindow: true }, function(tabs) {
      if (!tabs || !tabs[0]) return;
      chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_STATE' }, function(state) {
        if (chrome.runtime.lastError || !state) return;
        sessionData.tool = state.tool || 'AI Tool';
      });
    });
  });
});


// ── CSP-safe event wiring ────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  function on(id, evt, fn) {
    var el = document.getElementById(id); if (el) el.addEventListener(evt, fn);
  }
  // Disclaimer
  on('disclaimer-check', 'change', function() { onCheck(this); });
  on('btn-proceed', 'click', proceedFromDisclaimer);
  // Path chooser help
  document.addEventListener('click', function(e) {
    if (e.target.id === 'help-toggle' || e.target.closest('#help-toggle')) toggleHelp();
  });
  // Account confirms
  document.addEventListener('click', function(e) {
    var row = e.target.closest('.account-done-row');
    if (row) {
      var rowId = row.id, chkId = rowId.replace('-row','-check'), nextId = rowId.replace('-row','').replace('acct','').replace('pr-account','pr-next-1').replace('cr-account','cr-next-1');
      toggleAccountDone(rowId, chkId, nextId);
    }
  });
});
