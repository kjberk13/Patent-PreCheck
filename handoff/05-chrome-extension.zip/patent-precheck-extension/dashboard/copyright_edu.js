var selected = new Set();

var items = {
  'item-code':   { label: 'Source code (content.js, background.js, popup.js, dashboard.js, filing.js, eco_autofill.js)', icon: '💻' },
  'item-ui':     { label: 'User interface text and copy (labels, prompts, descriptions)', icon: '✍️' },
  'item-algo':   { label: 'Documentation and algorithm descriptions (IDF, spec, README)', icon: '📄' },
  'item-design': { label: 'UI visual design and layout (dashboard, panel, score ring)', icon: '🎨' },
};

function toggle(id) {
  var card = document.getElementById(id);
  var chk  = document.getElementById('chk-' + id.replace('item-',''));
  var svg  = document.getElementById('chk-' + id.replace('item-','') + '-svg');

  if (selected.has(id)) {
    selected.delete(id);
    card.classList.remove('selected');
    chk.style.background = '#fff';
    chk.style.borderColor = '#e5e7eb';
    if (svg) svg.style.display = 'none';
  } else {
    selected.add(id);
    card.classList.add('selected');
    chk.style.background = '#1D9E75';
    chk.style.borderColor = '#1D9E75';
    if (svg) svg.style.display = 'block';
  }
  updateSummary();
}

function updateSummary() {
  var sumBox  = document.getElementById('selection-summary');
  var sumItems = document.getElementById('summary-items');
  var ctaSel  = document.getElementById('cta-selection');
  var ctaItems = document.getElementById('cta-items');

  if (selected.size === 0) {
    sumBox.style.display = 'none';
    ctaSel.style.display = 'none';
    return;
  }

  sumBox.style.display = 'block';
  ctaSel.style.display = 'block';

  var html = '';
  var ctaHtml = '';
  selected.forEach(function(id) {
    var item = items[id];
    if (!item) return;
    html += '<div style="display:flex;align-items:center;gap:8px;font-size:12px;color:#374151">' +
      '<span style="color:#1D9E75;flex-shrink:0">✓</span>' +
      '<span>' + item.label + '</span>' +
    '</div>';
    ctaHtml += '<div class="cta-item"><span>' + item.icon + '</span><span>' + item.label + '</span></div>';
  });
  sumItems.innerHTML = html;
  ctaItems.innerHTML = ctaHtml;

  // Save selection to storage for wizard to use
  try {
    chrome.storage.local.set({ ppc_cr_selected_items: Array.from(selected) });
  } catch(e) {}
}

function toggleFaq(el) {
  el.classList.toggle('open');
}

// Pre-select source code and UI text as defaults (most common case)
document.addEventListener('DOMContentLoaded', function() {
  toggle('item-code');
  toggle('item-ui');
  toggle('item-algo');
});

// ── CSP-safe event wiring ────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  // Pre-select default items
  toggle('item-code');
  toggle('item-ui');
  toggle('item-algo');

  // FAQ toggles
  document.querySelectorAll('.faq-item').forEach(function(el) {
    el.addEventListener('click', function() { toggleFaq(this); });
  });

  // Checklist toggles
  ['item-code','item-ui','item-algo','item-design'].forEach(function(id) {
    var el = document.getElementById(id);
    if (el) el.addEventListener('click', function() { toggle(id); });
  });
});
