// background/background.js — Patent PreCheck service worker

chrome.runtime.onInstalled.addListener(function(details) {
  if (details.reason === 'install') {
    chrome.storage.local.set({
      ppc_enabled:      true,
      ppc_score:        null,
      ppc_journal:      [],
      ppc_install_date: Date.now(),
      ppc_panel_closed: false,
    });
  }
});

// ── Message relay ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function(msg, sender, reply) {

  // Open dashboard tab — guard against tabs API being unavailable
  if (msg.type === 'OPEN_DASHBOARD') {
    try {
      var url = chrome.runtime.getURL('dashboard/dashboard.html');
      chrome.tabs.create({ url: url }, function() {
        if (chrome.runtime.lastError) {
          console.warn('Patent PreCheck: could not open dashboard -', chrome.runtime.lastError.message);
        }
      });
    } catch(e) {
      console.warn('Patent PreCheck: OPEN_DASHBOARD error -', e.message);
    }
    return false;
  }

  // Open copyright wizard tab
  if (msg.type === 'OPEN_COPYRIGHT') {
    try {
      var url = chrome.runtime.getURL('dashboard/copyright.html');
      chrome.tabs.create({ url: url }, function() {
        if (chrome.runtime.lastError) {
          console.warn('Patent PreCheck: could not open copyright wizard -', chrome.runtime.lastError.message);
        }
      });
    } catch(e) {
      console.warn('Patent PreCheck: OPEN_COPYRIGHT error -', e.message);
    }
    return false;
  }

  // Relay GET_STATE from popup to active tab content script
  if (msg.type === 'POPUP_GET_STATE') {
    try {
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (chrome.runtime.lastError) {
          try { reply({ error: 'query failed' }); } catch(e) {}
          return;
        }
        var tab = tabs && tabs[0];
        if (!tab) {
          try { reply({ error: 'no active tab' }); } catch(e) {}
          return;
        }
        chrome.tabs.sendMessage(tab.id, { type: 'GET_STATE' }, function(res) {
          if (chrome.runtime.lastError) {
            try { reply({ error: 'content script not ready' }); } catch(e) {}
            return;
          }
          try { reply(res || { error: 'no response' }); } catch(e) {}
        });
      });
    } catch(e) {
      try { reply({ error: e.message }); } catch(e2) {}
    }
    return true; // keep channel open for async reply
  }

  // Toggle panel in active tab
  if (msg.type === 'POPUP_TOGGLE_PANEL') {
    try {
      chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        if (chrome.runtime.lastError) return;
        var tab = tabs && tabs[0];
        if (!tab) return;
        chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_PANEL' }, function() {
          if (chrome.runtime.lastError) {} // ignore — panel may not be injected yet
        });
      });
    } catch(e) {}
    return false;
  }

  return false;
});
