# Patent PreCheck — Chrome Extension

Real-time patent protection for your AI-assisted ideas.

## What it does
- Detects which AI tool you're using (works on any AI tool in Chrome)
- Captures your conversation turns and separates your contributions from AI output
- Computes your Patent PreCheck Score using the proprietary AI Patentability Algorithm
- Fires hygiene checks at the right moments to capture legal evidence
- Stores a dated journal of decisions, insights, and documentation

## Supported tools (auto-detected)
ChatGPT · Claude · Gemini · Perplexity · Microsoft Copilot · Grok · Replit · Bolt · v0 · Cursor · Any other AI tool

## Loading in Chrome (developer mode)
1. Open Chrome → go to chrome://extensions
2. Enable "Developer mode" (top right toggle)
3. Click "Load unpacked"
4. Select this folder
5. The Patent PreCheck icon appears in your toolbar

## Files
- manifest.json          — Chrome extension manifest (v3)
- content/content.js     — Injected into every page; does the scoring and panel UI
- styles/panel.css       — Styles for the injected panel
- background/background.js — Service worker; handles storage and alarms
- popup/popup.html       — Toolbar icon popup
- popup/popup.js         — Popup logic
- src/                   — TypeScript source (compile before building)

## Architecture
The content script runs entirely in the browser. The AI Patentability Algorithm
runs server-side at api.patentprecheck.com — the extension sends anonymised
turn signals and receives the authoritative Patent PreCheck Score.
No conversation text is stored on Patent PreCheck servers.
