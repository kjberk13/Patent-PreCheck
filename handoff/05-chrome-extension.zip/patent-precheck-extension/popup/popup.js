// popup/popup.js

const AI_TOOLS = ['chatgpt','openai','claude','gemini','google','perplexity','copilot','grok','replit','bolt','v0.dev','cursor'];

function isAiToolTab(url) {
  if (!url) return false;
  const lower = url.toLowerCase();
  return AI_TOOLS.some(t => lower.includes(t));
}

async function getActiveTab() {
  return new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) { resolve(tabs && tabs[0]); });
  });
}

function updateScore(data) {
  if (!data || data.error) return;

  const s = data.score || {};
  const overall = s.overall || 0;

  document.getElementById('ring-num').textContent = overall || '–';

  const circumference = 201;
  const offset = circumference - (overall / 100) * circumference;
  const ring = document.getElementById('ring-fill');
  ring.style.strokeDashoffset = offset;
  ring.style.stroke = overall >= 80 ? '#1D9E75' : overall >= 60 ? '#378ADD' : overall >= 40 ? '#EF9F27' : '#E24B4A';

  const band = document.getElementById('score-band');
  band.textContent = overall >= 80 ? 'File-ready'
    : overall >= 60 ? 'Strong position'
    : overall >= 40 ? 'Building strength'
    : overall >  0  ? 'Not yet ready'
    : 'Start your conversation';
  band.style.color = overall >= 80 ? '#1D9E75' : overall >= 60 ? '#378ADD' : overall >= 40 ? '#EF9F27' : overall > 0 ? '#E24B4A' : '#9ca3af';

  // Breakdown
  const c = s.conception || 0, e = s.eligibility || 0, d = s.documentation || 0;
  document.getElementById('bar-c').style.width = c + '%';
  document.getElementById('bar-e').style.width = e + '%';
  document.getElementById('bar-d').style.width = d + '%';
  document.getElementById('val-c').textContent = c || '–';
  document.getElementById('val-e').textContent = e || '–';
  document.getElementById('val-d').textContent = d || '–';

  document.getElementById('stat-turns').textContent  = data.turns   || '–';
  document.getElementById('stat-human').textContent  = data.human   || '–';
  document.getElementById('stat-journal').textContent= data.journal  || '–';
  document.getElementById('tool-badge').textContent  = data.tool    || 'AI Tool';

  document.getElementById('status-dot').className   = 'status-dot';
  document.getElementById('status-text').textContent = `Active on ${data.tool || 'this page'}`;
}

async function init() {
  const tab = await getActiveTab();

  if (!tab || !isAiToolTab(tab.url)) {
    document.getElementById('status-dot').className    = 'status-dot inactive';
    document.getElementById('status-text').textContent = 'Open an AI tool to start tracking';
    document.getElementById('tool-badge').textContent  = 'Not an AI tool';
    return;
  }

  // Request state from content script
  chrome.tabs.sendMessage(tab.id, { type: 'GET_STATE' }, res => {
    if (chrome.runtime.lastError) {
      document.getElementById('status-text').textContent = 'Loading...';
      return;
    }
    updateScore(res);
  });

  // Buttons
  document.getElementById('btn-open-panel').addEventListener('click', () => {
    chrome.tabs.sendMessage(tab.id, { type: 'TOGGLE_PANEL' });
    window.close();
  });

  document.getElementById('btn-wrap').addEventListener('click', () => {
    chrome.tabs.sendMessage(tab.id, { type: 'FIRE_WRAP' });
    window.close();
  });

  document.getElementById('btn-dashboard').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
  });
}

init();
