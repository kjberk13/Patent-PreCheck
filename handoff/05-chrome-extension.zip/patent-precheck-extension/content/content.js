(function() {
'use strict';
if (window.__ppcLoaded) return;
window.__ppcLoaded = true;

// ── Tool detection ─────────────────────────────────────────────────────────
function detectToolName() {
  const h = location.href;
  if (h.includes('claude.ai'))         return 'Claude';
  if (h.includes('chatgpt.com') || h.includes('chat.openai.com')) return 'ChatGPT';
  if (h.includes('gemini.google.com')) return 'Gemini';
  if (h.includes('perplexity.ai'))     return 'Perplexity';
  if (h.includes('grok.x.ai'))         return 'Grok';
  if (h.includes('copilot.microsoft')) return 'Copilot';
  return 'AI Tool';
}
const SELECTORS = {
  'Claude':     { human:['[data-testid="human-turn"]','.font-user-message'], ai:['[data-testid="ai-turn"]','.font-claude-message','div.prose'] },
  'ChatGPT':    { human:['[data-message-author-role="user"]'],               ai:['[data-message-author-role="assistant"]'] },
  'Gemini':     { human:['.query-text','.user-query-bubble'],                ai:['.response-content','.model-response-text'] },
  'Perplexity': { human:['[class*="userMessage"]'],                          ai:['[class*="answerMessage"]','.prose'] },
  'Grok':       { human:['[data-testid="userMessage"]'],                     ai:['[data-testid="botMessage"]'] },
  'Copilot':    { human:['[class*="userMessage"]'],                          ai:['[class*="botMessage"]'] },
};

// ── State ──────────────────────────────────────────────────────────────────
let toolName    = detectToolName();
let sels        = SELECTORS[toolName] || { human:[], ai:[] };
let turns       = [], journal = [], eventLog = [];
let score       = { overall:0, conception:0, eligibility:0, documentation:10 };
let seenKeys    = new Set();
let activeCheck = null;
let panelOpen   = true;
let userTyping  = false;   // ← KEY: prevents panel rebuild while user types
let savedPos    = null;    // persisted drag position {right, bottom}
let lastCheckAt = 0, checksSession = 0;
const MAX_CHECKS = 8, MIN_GAP = 5 * 60 * 1000;

// ── Scoring ────────────────────────────────────────────────────────────────
const SIG_C = [/key insight/i,/i realized/i,/i figured out/i,/the mechanism/i,/my approach/i,/i measured/i,/i tested/i,/unlike existing/i,/specifically because/i,/from profiling/i,/i discovered/i,/what makes this different/i,/my idea/i,/i invented/i,/i designed/i];
const SIG_D = [/\d+\s*(ms|seconds?|percent|%|kb|mb|hz)/i,/production\s+data/i,/our\s+system/i,/we\s+measured/i,/benchmark/i,/threshold/i,/latency/i];
const SIG_W = [/let'?s use/i,/we should use/i,/just use/i,/can we use/i,/how do i/i];

function scoreTurn(t) {
  let s = 30;
  s += Math.min(SIG_C.filter(r=>r.test(t)).length*15,35);
  s += Math.min(SIG_D.filter(r=>r.test(t)).length*10,25);
  if(t.length>200)s+=5; if(t.length>600)s+=5;
  s -= SIG_W.filter(r=>r.test(t)).length*10;
  if(t.trim().endsWith('?')&&t.split(' ').length<12)s-=15;
  return Math.max(5,Math.min(100,Math.round(s)));
}
function isConception(t){return SIG_C.filter(r=>r.test(t)).length>=2||(SIG_C.some(r=>r.test(t))&&SIG_D.some(r=>r.test(t)));}

function recompute() {
  const h=turns.filter(t=>t.author==='human');
  if(!h.length){updateNumbers();return;}
  const sc=h.map(t=>t.score);
  const top3=[...sc].sort((a,b)=>b-a).slice(0,3);
  score.conception=Math.round(top3.reduce((a,b)=>a+b,0)/top3.length);
  score.documentation=Math.min(100,10+journal.length*14);
  score.eligibility=Math.min(100,Math.round(40+(sc.reduce((a,b)=>a+b,0)/sc.length)*0.3+(h.length/Math.max(turns.length,1))*15));
  score.overall=Math.round(score.conception*0.5+score.eligibility*0.35+score.documentation*0.15);
  chrome.storage.local.set({ppc_score:score});
  updateFab();          // always update FAB badge
  if(!userTyping) {
    if(panelOpen) renderFull();   // full re-render if panel is open
    else updateNumbers();         // lightweight update of numeric elements only
  }
}

// ── Capture ────────────────────────────────────────────────────────────────
function captureEl(el,author) {
  const text=(el.innerText||el.textContent||'').trim();
  if(text.length<12)return;
  const key=author+':'+text.slice(0,100);
  if(seenKeys.has(key))return;
  seenKeys.add(key);
  const turn={id:`t-${Date.now()}`,author,text:text.slice(0,6000),timestamp:Date.now(),tool:toolName,score:author==='human'?scoreTurn(text):0};
  turns.push(turn);
  if(author==='human'){
    addLog(`Your message (strength ${turn.score}/100)`,'#1D9E75');
    if(isConception(text)&&canFire())setTimeout(()=>fireCheck('conception'),1200);
    else if(turn.score>=65&&canFire()&&Math.random()<0.4)setTimeout(()=>fireCheck('strong'),1500);
  } else {
    addLog(`${toolName} response captured`,'#9ca3af');
    const num=text.match(/\b(\d+(?:\.\d+)?)\s*(?:ms|seconds?|percent|%|threshold)\b/i);
    if(num&&canFire())setTimeout(()=>fireCheck('param',num[1]),1200);
  }
  const aiC=turns.filter(t=>t.author==='ai').length;
  if(turns.length>=6&&aiC/turns.length>0.65&&canFire()&&Math.random()<0.4)setTimeout(()=>fireCheck('ratio'),2000);
  recompute();
}
function scanSels(list,author){list.forEach(s=>{try{document.querySelectorAll(s).forEach(el=>captureEl(el,author));}catch(e){}});}
function scanClaude(){
  if(toolName!=='Claude')return;
  document.querySelectorAll('div[class*="grid"]>div,main div[class*="flex"]>div').forEach(div=>{
    const text=(div.innerText||'').trim();
    if(text.length<15||text.length>10000)return;
    const key='cl:'+text.slice(0,80);
    if(seenKeys.has(key))return;
    const cls=div.className||'';
    const isU=cls.includes('user')||cls.includes('human')||!!div.querySelector('[class*="user"]');
    const isA=cls.includes('assistant')||cls.includes('claude')||cls.includes('prose')||!!div.querySelector('.prose');
    if(isU&&!isA)captureEl(div,'human');
    else if(isA&&!isU)captureEl(div,'ai');
  });
}
function scan(){scanSels(sels.human,'human');scanSels(sels.ai,'ai');scanClaude();watchInput();}

// Watch real-time typing in the AI tool's input box
function watchInput(){
  document.querySelectorAll('.ProseMirror,[contenteditable="true"],textarea,#prompt-textarea').forEach(inp=>{
    if(inp.__ppcW)return; inp.__ppcW=true;
    inp.addEventListener('input',()=>{
      const t=(inp.innerText||inp.value||'').trim();
      if(t.length<5){hideTyping();return;}
      const s=scoreTurn(t), col=s>=70?'#1D9E75':s>=45?'#EF9F27':'#E24B4A';
      const conc=isConception(t);
      const area=document.getElementById('ppc-typing-area');
      if(!area)return;
      area.style.display='block';
      area.innerHTML=`<div style="font-size:9px;font-weight:700;color:#9ca3af;letter-spacing:.06em;text-transform:uppercase;margin-bottom:4px">AS YOU TYPE — <span style="color:${col}">${s}/100</span></div>
        <div style="height:4px;background:#f0f0f0;border-radius:2px;overflow:hidden;margin-bottom:${conc?'5px':'0'}"><div style="height:100%;width:${s}%;background:${col};border-radius:2px;transition:width .3s"></div></div>
        ${conc?`<div style="font-size:10px;color:#0C447C;background:#E6F1FB;padding:3px 8px;border-radius:5px;margin-top:4px">Your idea moment — we'll prompt you when you send</div>`:''}`;
    });
  });
}
function hideTyping(){const a=document.getElementById('ppc-typing-area');if(a)a.style.display='none';}

// ── Checks ─────────────────────────────────────────────────────────────────
function canFire(){return checksSession<MAX_CHECKS&&Date.now()-lastCheckAt>MIN_GAP&&!activeCheck;}

const CDEFS={
  conception:{scoreGain:15,category:1,band:'#E24B4A',label:'YOUR IDEA',title:'You just had an original idea',intro:'You said something that sounds like your own original thinking — not something the AI came up with.',question:'Describe your idea in your own words — not the AI\'s language, yours. What makes it different or new?',why:'Saving this now creates a dated record that this idea came from you — before anyone else.',ph:'e.g. The key mechanism is that inter-arrival variance captures dispersion that moving averages discard. This lets you distinguish burst traffic from high-load — prior approaches cannot do this...',guidance:'Patent law says the idea must clearly be yours. Writing it down now, in your own words, is how you show that.'},
  param:v=>({scoreGain:10,category:3,band:'#EF9F27',label:'SUGGESTED',title:`AI suggested "${v}" — did that come from your data?`,intro:'The AI suggested a specific number. If that came from your own data or experience, say so briefly.',question:'Did this number come from your own experience or data? Even a short answer helps show it was your call.',why:'If this number came from your own work or data, saying so shows it was yours — not just the AI suggestion.',ph:`e.g. I confirmed this from 90 days of production traffic — the 90th percentile matched that value...`,guidance:'If a number or approach came from your own experience or data, that matters for establishing it as yours.'}),
  strong:{scoreGain:8,category:1,band:'#378ADD',label:'SAVE THIS',title:'This looks worth saving',intro:'That message had something specific and original in it. Worth saving so it is on the record.',question:'Is there anything else from your own experience the AI wouldn\'t know?',why:'Details the AI couldn\'t know are some of the strongest patent evidence available.',ph:'e.g. My insight draws from our March incident where burst buildup went undetected 40 minutes before failure...',guidance:'Showing that you spotted the problem or approach before the AI did is strong evidence the idea is yours.'},
  ratio:{scoreGain:12,category:3,band:'#EF9F27',label:'SUGGESTED',title:'Most of this is from the AI',intro:'A lot of this conversation is the AI talking. It helps to write down what direction you were giving it.',question:'What were you telling the AI to do, and why? What did you know that shaped the direction you gave it?',why:'Showing that you were in charge — that you gave the AI specific direction — is what makes the idea protectable.',ph:'e.g. Every AI suggestion was filtered through requirements I set: variance-based detection (my insight)...',guidance:'There is a difference between saying make me something and giving specific direction. Write down what made yours specific.'},
  wrap:{scoreGain:12,category:1,band:'#0C447C',label:'BEFORE YOU GO',title:'Before you go — what was your idea?',intro:'Before you close this tab, take 2 minutes to write down what the original idea was — in your own words.',question:'What was your original idea here? What came from you — not from the AI? Write it in plain language.',why:'What you write here, right now, with todays date attached, is your record of what you came up with and when.',ph:'e.g. The queue-depth weighting factor was entirely mine — no AI suggested it. I saw the failure mode in our March incident logs...',guidance:'Write down what came from you independently — not what the AI produced, but what you brought to it.'},
};

function fireCheck(type,val){
  if(!canFire())return;
  const def=typeof CDEFS[type]==='function'?CDEFS[type](val):CDEFS[type];
  activeCheck={...def,type};
  lastCheckAt=Date.now(); checksSession++;
  addLog(`Prompt ready: ${def.title}`,def.band);
  // Don't force panel open — show badge on FAB, let user open when ready
  updateFab();
  if(panelOpen) renderFull();
}

// ── Log ────────────────────────────────────────────────────────────────────
function addLog(msg,color='#9ca3af'){
  const t=new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
  eventLog.unshift({msg,color,t});
  if(eventLog.length>8)eventLog.pop();
  const el=document.getElementById('ppc-log');
  if(el)el.innerHTML=eventLog.map(e=>`<div style="display:flex;gap:5px;padding:4px 0;border-bottom:0.5px solid #f5f5f5;font-size:10px"><span style="color:${e.color};flex-shrink:0">●</span><span style="flex:1;color:#6b7280;line-height:1.3">${e.msg}</span><span style="color:#ccc;flex-shrink:0">${e.t}</span></div>`).join('');
}

// ── updateNumbers — safe, never touches the check form ─────────────────────
function updateNumbers(){
  const s=score.overall,col=scol(s);
  const setT=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v;};
  const setS=(id,v)=>{const e=document.getElementById(id);if(e)e.style[Object.keys(v)[0]]=Object.values(v)[0];};

  setT('ppc-score-num', s||'–');
  setT('ppc-score-band', sband(s));
  setS('ppc-score-band',{color:col});
  setT('ppc-score-note', s>0?'Powered by the AI Patentability Algorithm':'Start your conversation — your score will appear here');

  ['c','e','d'].forEach((k,i)=>{
    const v=[score.conception,score.eligibility,score.documentation][i];
    setT(`ppc-val-${k}`,v||'–');
    const bar=document.getElementById(`ppc-bar-${k}`);
    if(bar)bar.style.width=(v||0)+'%';
  });

  const h=turns.filter(t=>t.author==='human').length;
  const a=turns.filter(t=>t.author==='ai').length;
  setT('ppc-stat-total',turns.length);
  setT('ppc-stat-human',h);
  setT('ppc-stat-ai',a);
  setT('ppc-stat-saved',journal.length);

  // Update ring
  const ring=document.getElementById('ppc-ring');
  if(ring){
    const circ=188,offset=s>0?circ-(s/100)*circ:circ;
    ring.style.strokeDashoffset=offset;
    ring.style.stroke=col;
    const bg=document.getElementById('ppc-ring-bg');
    if(bg)bg.setAttribute('fill',sbg(s));
  }
  const num=document.getElementById('ppc-score-num');
  if(num)num.setAttribute('fill',col);

  addLog('');// refresh log display
}

// ── Colours ────────────────────────────────────────────────────────────────
function scol(s){return s>=80?'#1D9E75':s>=60?'#378ADD':s>=40?'#EF9F27':s>0?'#E24B4A':'#d1d5db';}
function sband(s){return s>=80?'File-ready':s>=60?'Strong position':s>=40?'Building strength':s>0?'Not yet ready':s===0?'Start your conversation':'';}
function sbg(s){return s>=80?'#EAF3DE':s>=60?'#E6F1FB':s>=40?'#FAEEDA':s>0?'#FCEBEB':'#f5f5f5';}

// ── Full render — only called when no user typing ─────────────────────────
function renderFull(){
  const root=document.getElementById('ppc-panel-root');
  if(!root||!panelOpen)return;
  const s=score.overall,col=scol(s),band=sband(s);
  const human=turns.filter(t=>t.author==='human');
  const ai=turns.filter(t=>t.author==='ai');
  const circ=188,offset=s>0?circ-(s/100)*circ:circ;

  root.innerHTML=`
<div style="width:304px;background:#fff;border-radius:16px;border:0.5px solid #e5e7eb;box-shadow:0 4px 24px rgba(0,0,0,.10);display:flex;flex-direction:column;max-height:82vh;overflow-y:auto;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">

  <!-- Sticky header — drag handle -->
  <div id="ppc-drag-handle" style="position:sticky;top:0;z-index:10;padding:12px 14px 9px;border-bottom:0.5px solid #f0f0f0;background:#fff;cursor:grab;user-select:none">
    <div style="display:flex;align-items:center;gap:7px;margin-bottom:2px">
      <svg width="17" height="17" viewBox="0 0 18 18" fill="none"><circle cx="9" cy="9" r="8" fill="#0C447C"/><path d="M5.5 9l2.5 2.5 5-5" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
      <span style="font-size:14px;font-weight:700;color:#0C447C;flex:1">Patent PreCheck</span>
      <span style="font-size:10px;background:#E6F1FB;color:#185FA5;padding:2px 8px;border-radius:20px;font-weight:500">${toolName}</span>
      <button id="ppc-close" style="background:none;border:none;font-size:22px;color:#ccc;cursor:pointer;line-height:1;padding:0 3px;flex-shrink:0">×</button>
    </div>
    <div style="font-size:10px;color:#9ca3af">Tracking what came from you vs the AI · <span style="opacity:.6">drag to move</span></div>
  </div>

  <!-- Active check — at the top, full form -->
  ${activeCheck?`
  <div id="ppc-check-area" style="padding:14px;border-bottom:0.5px solid #f0f0f0;background:#fffbeb">
    <div style="display:inline-block;font-size:9px;font-weight:700;color:${activeCheck.band};background:${activeCheck.band}18;padding:3px 10px;border-radius:20px;margin-bottom:8px;letter-spacing:.06em">${activeCheck.label}</div>
    <div style="font-size:14px;font-weight:700;color:#111827;margin-bottom:5px;line-height:1.3">${activeCheck.title}</div>
    <div style="font-size:11px;color:#6b7280;background:#fff;border-radius:8px;padding:7px 9px;margin-bottom:7px;line-height:1.5;border:0.5px solid #f0f0f0">${activeCheck.intro}</div>
    <div style="font-size:12px;font-weight:600;color:#374151;margin-bottom:5px;line-height:1.5">${activeCheck.question}</div>
    <div style="font-size:10px;color:#185FA5;background:#E6F1FB;padding:5px 9px;border-radius:7px;margin-bottom:7px;line-height:1.4">${activeCheck.why}</div>
    <textarea id="ppc-ta" rows="4" placeholder="${activeCheck.ph}" style="width:100%;border:1.5px solid #e5e7eb;border-radius:10px;padding:10px 11px;font-size:11px;resize:vertical;min-height:80px;line-height:1.6;color:#111;background:#fff;font-family:inherit;display:block;box-sizing:border-box"></textarea>
    <div id="ppc-chars" style="font-size:10px;color:#9ca3af;margin:5px 0 6px">Write at least 40 characters — more detail = stronger legal evidence</div>
    <div style="font-size:10px;color:#6b7280;padding:5px 9px;background:#fff;border-radius:7px;border-left:3px solid ${activeCheck.band};margin-bottom:10px;line-height:1.45">${activeCheck.guidance}</div>
    <div style="display:flex;gap:8px">
      <button id="ppc-save" style="flex:1;background:#0C447C;color:#fff;border:none;border-radius:10px;padding:11px;font-size:12px;font-weight:600;cursor:pointer;opacity:.35" disabled>Save as legal evidence (+${activeCheck.scoreGain} pts)</button>
      <button id="ppc-skip" style="background:#fff;border:1.5px solid #e5e7eb;border-radius:10px;padding:11px 14px;font-size:11px;color:#9ca3af;cursor:pointer">Skip</button>
    </div>
  </div>`:''}

  <!-- Score section -->
  <div style="padding:14px 14px 12px;border-bottom:0.5px solid #f0f0f0;text-align:center">
    <div style="font-size:9px;font-weight:600;color:#9ca3af;letter-spacing:.08em;text-transform:uppercase;margin-bottom:10px">Your Patent PreCheck Score</div>
    <svg width="88" height="88" viewBox="0 0 96 96" style="display:block;margin:0 auto 7px">
      <circle id="ppc-ring-bg" cx="48" cy="48" r="38" fill="${sbg(s)}" stroke="none"/>
      <circle cx="48" cy="48" r="38" fill="none" stroke="#f0f0f0" stroke-width="7"/>
      <circle id="ppc-ring" cx="48" cy="48" r="38" fill="none" stroke="${col}" stroke-width="7"
        stroke-dasharray="${circ}" stroke-dashoffset="${offset}" stroke-linecap="round"
        transform="rotate(-90 48 48)" style="transition:stroke-dashoffset .8s,stroke .4s"/>
      <text id="ppc-score-num" x="48" y="55" text-anchor="middle" font-size="${s>9?'26':'16'}" font-weight="700" fill="${col}" font-family="-apple-system,sans-serif">${s>0?s:'–'}</text>
    </svg>
    <div id="ppc-score-band" style="font-size:12px;font-weight:700;color:${col};margin-bottom:2px">${band}</div>
    <div id="ppc-score-note" style="font-size:9px;color:#ccc;margin-bottom:12px">${s>0?'Powered by the AI Patentability Algorithm':'Start your conversation — your score will appear here'}</div>

    <!-- 4-band scale -->
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:4px;margin-bottom:12px">
      ${[['0–39','Not yet ready','#FCEBEB','#E24B4A'],['40–59','Building','#FAEEDA','#EF9F27'],['60–79','Strong','#E6F1FB','#378ADD'],['80–100','File-ready','#EAF3DE','#1D9E75']].map(([r,l,bg,tc])=>`<div style="background:${bg};border-radius:7px;padding:5px 2px;text-align:center"><div style="font-size:10px;font-weight:700;color:${tc}">${r}</div><div style="font-size:8px;color:${tc};margin-top:1px">${l}</div></div>`).join('')}
    </div>

    <!-- 3 metrics -->
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:7px">
      ${[['How much came from you',score.conception,'c','#0C447C'],['Can it be patented?',score.eligibility,'e','#378ADD'],['How well documented',score.documentation,'d','#1D9E75']].map(([label,val,k,c])=>`
      <div style="background:#f9fafb;border-radius:9px;padding:8px 4px;text-align:center">
        <div id="ppc-val-${k}" style="font-size:17px;font-weight:700;color:${c};line-height:1">${val||'–'}</div>
        <div style="height:3px;background:#f0f0f0;border-radius:2px;overflow:hidden;margin:4px 0"><div id="ppc-bar-${k}" style="height:100%;width:${val||0}%;background:${c};border-radius:2px;transition:width .6s"></div></div>
        <div style="font-size:8px;color:#9ca3af;line-height:1.3">${label}</div>
      </div>`).join('')}
    </div>
  </div>

  <!-- Captured stats -->
  <div style="padding:10px 14px;border-bottom:0.5px solid #f0f0f0">
    <div style="font-size:9px;font-weight:700;color:#374151;letter-spacing:.05em;margin-bottom:7px">WHAT WE'VE CAPTURED</div>
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:5px">
      ${[['Total',turns.length,'ppc-stat-total','#374151'],['Yours',human.length,'ppc-stat-human','#1D9E75'],[toolName.slice(0,5),ai.length,'ppc-stat-ai','#9ca3af'],['Saved',journal.length,'ppc-stat-saved','#EF9F27']].map(([label,n,id,c])=>`
      <div style="background:#f9fafb;border-radius:9px;padding:7px 3px;text-align:center">
        <div id="${id}" style="font-size:18px;font-weight:700;color:${c};line-height:1">${n}</div>
        <div style="font-size:8px;color:#9ca3af;margin-top:2px">${label}</div>
      </div>`).join('')}
    </div>
  </div>

  <!-- Real-time typing feedback -->
  <div id="ppc-typing-area" style="display:none;padding:8px 14px;border-bottom:0.5px solid #f0f0f0;background:#f8fff8"></div>

  <!-- Empty state -->
  ${turns.length===0?`<div style="padding:14px;text-align:center;background:#fafafa">
    <div style="font-size:13px;font-weight:600;color:#374151;margin-bottom:5px">Listening to your conversation</div>
    <div style="font-size:11px;color:#9ca3af;line-height:1.65">As you chat with ${toolName}, Patent PreCheck captures your messages, tracks what came from you versus the AI, and scores how protectable your idea is.</div>
  </div>`:''}

  <!-- Action buttons -->
  <div style="padding:9px 12px;border-bottom:0.5px solid #f0f0f0;display:flex;gap:7px">
    <button id="ppc-btn-d" style="flex:1;border:1.5px solid #e5e7eb;border-radius:9px;background:#fff;padding:8px 4px;font-size:10px;font-weight:600;color:#374151;cursor:pointer;line-height:1.3">Log a<br>decision</button>
    <button id="ppc-btn-c" style="flex:1;border:1.5px solid #e5e7eb;border-radius:9px;background:#fff;padding:8px 4px;font-size:10px;font-weight:600;color:#374151;cursor:pointer;line-height:1.3">Log an<br>idea</button>
    <button id="ppc-btn-w" style="flex:1;border:1.5px solid #0C447C;border-radius:9px;background:#E6F1FB;padding:8px 4px;font-size:10px;font-weight:600;color:#0C447C;cursor:pointer;line-height:1.3">Before<br>you go</button>
  </div>

  <!-- Event log -->
  <div id="ppc-log" style="padding:6px 14px;max-height:72px;overflow-y:auto;background:#fafafa"></div>

  <div style="padding:6px 14px;font-size:9px;color:#d1d5db;text-align:center">Patent PreCheck · Powered by the AI Patentability Algorithm · <span id='ppc-rescan' style='cursor:pointer;text-decoration:underline;opacity:.7' onclick='(function(){window.__ppcRescan&&window.__ppcRescan();})()'>rescan</span></div>
</div>`;

  wireEvents();
  addLog('');
  watchInput();
}

// ── Wire events — called after every full render ───────────────────────────
function wireEvents(){
  const on=(id,fn)=>{const el=document.getElementById(id);if(el)el.addEventListener('click',fn);};
  on('ppc-btn-dash', ()=>{ chrome.runtime.sendMessage({type:'OPEN_DASHBOARD'}); });

  on('ppc-close',()=>{
    const p=document.getElementById('ppc-panel-root');
    if(p)p.style.display='none';
    panelOpen=false;
    chrome.storage.local.set({ppc_panel_closed:true});
    updateFab(); // show badge so user knows something is waiting
  });
  on('ppc-btn-d',()=>fireCheck('strong'));
  on('ppc-btn-c',()=>fireCheck('conception'));
  on('ppc-btn-w',()=>fireCheck('wrap'));
  on('ppc-skip', ()=>{ activeCheck=null; userTyping=false; renderFull(); });

  const ta  = document.getElementById('ppc-ta');
  const btn = document.getElementById('ppc-save');
  if(ta && btn){
    // Mark user as typing — prevents panel rebuild from destroying their input
    ta.addEventListener('focus', ()=>{ userTyping=true; });
    ta.addEventListener('blur',  ()=>{ userTyping=false; });
    ta.addEventListener('input', ()=>{
      const ok = ta.value.trim().length >= 40;
      btn.disabled   = !ok;
      btn.style.opacity = ok ? '1' : '0.35';
      const cc = document.getElementById('ppc-chars');
      if(cc){
        cc.textContent = ok
          ? 'Good — enough detail to be useful legal evidence ✓'
          : `${40-ta.value.trim().length} more characters recommended`;
        cc.style.color = ok ? '#1D9E75' : '#9ca3af';
      }
    });
    on('ppc-save', ()=>{
      const answer = ta ? ta.value.trim() : '';
      if(answer.length < 40 || !activeCheck) return;
      journal.push({
        id:`j-${Date.now()}`, timestamp:Date.now(),
        category:activeCheck.category, trigger:activeCheck.type,
        answer, scoreGain:activeCheck.scoreGain, tool:toolName, url:location.href
      });
      addLog(`Evidence saved · +${activeCheck.scoreGain} pts · ${journal.length} total`,'#1D9E75');
      chrome.storage.local.set({ppc_journal:journal});
      activeCheck = null;
      userTyping  = false;
      recompute();
    });
  }
}


// ── FAB badge — shown when panel is closed but there's something to see ──────
function updateFab(){
  const fab = document.getElementById('ppc-fab');
  if(!fab) return;
  const s = score.overall;
  const hasCheck = !!activeCheck;
  const scoreStr = s > 0 ? s : '';

  // Update score display on FAB
  const scoreEl = fab.querySelector('.ppc-fab-score');
  if(scoreEl) scoreEl.textContent = scoreStr;

  // Badge: red dot when panel closed AND (check pending OR score changed)
  let badge = fab.querySelector('.ppc-fab-badge');
  if(!panelOpen && (hasCheck || s > 0)){
    if(!badge){
      badge = document.createElement('div');
      badge.className = 'ppc-fab-badge';
      badge.style.cssText = 'position:absolute;top:-3px;right:-3px;width:10px;height:10px;border-radius:50%;background:#E24B4A;border:2px solid #fff';
      fab.style.position = 'relative';
      fab.appendChild(badge);
    }
    badge.style.background = hasCheck ? '#E24B4A' : '#1D9E75';
  } else if(badge){
    badge.remove();
  }
}

// ── Inject shell ───────────────────────────────────────────────────────────
// ── Inject shell — bottom-right by default, draggable by header ────────────
function inject(){
  if(document.getElementById('ppc-root'))return;

  const root=document.createElement('div');
  root.id='ppc-root';
  const iR=(savedPos&&savedPos.right!=null)?savedPos.right:20;
  const iB=(savedPos&&savedPos.bottom!=null)?savedPos.bottom:20;
  root.style.cssText=`position:fixed;bottom:${iB}px;right:${iR}px;z-index:2147483647;display:flex;flex-direction:column;align-items:flex-end;gap:10px`;

  const pr=document.createElement('div');
  pr.id='ppc-panel-root';
  root.appendChild(pr);

  const fab=document.createElement('button');
  fab.id='ppc-fab';
  fab.title='Patent PreCheck — click to open';
  fab.style.cssText='width:52px;height:52px;border-radius:50%;background:#0C447C;border:none;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 3px 14px rgba(12,68,124,.35);gap:2px;flex-shrink:0;transition:transform .15s';
  fab.innerHTML=`<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="#fff" stroke-width="1.5"/><path d="M6.5 10l2.5 2.5 5.5-5.5" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><span class="ppc-fab-score" style="font-size:10px;color:#fff;font-weight:700;line-height:1"></span>`;
  fab.addEventListener('mouseenter',()=>fab.style.transform='scale(1.07)');
  fab.addEventListener('mouseleave',()=>fab.style.transform='scale(1)');
  fab.addEventListener('click',()=>{
    const p=document.getElementById('ppc-panel-root');
    if(!p)return;
    const showing=p.style.display!=='none'&&p.innerHTML!=='';
    p.style.display=showing?'none':'block';
    panelOpen=!showing;
    if(!showing){
      chrome.storage.local.set({ppc_panel_closed:false});
      renderFull();           // always re-render with latest scores on open
      updateNumbers();        // also force-update any numeric elements
    } else {
      chrome.storage.local.set({ppc_panel_closed:true});
    }
    updateFab();
  });
  root.appendChild(fab);
  document.body.appendChild(root);
  makeDraggable(root);
  renderFull();
  addLog(`Patent PreCheck active · monitoring ${toolName}`,'#0C447C');
}

function makeDraggable(root){
  let dragging=false,startX=0,startY=0,origLeft=0,origTop=0;
  function startDrag(e){
    if(!e.target.closest('#ppc-drag-handle'))return;
    e.preventDefault();
    dragging=true;
    const r=root.getBoundingClientRect();
    origLeft=r.left; origTop=r.top;
    startX=e.clientX; startY=e.clientY;
    root.style.right='auto'; root.style.bottom='auto';
    root.style.left=origLeft+'px'; root.style.top=origTop+'px';
    document.addEventListener('mousemove',onMove);
    document.addEventListener('mouseup',endDrag);
  }
  function onMove(e){
    if(!dragging)return;
    root.style.left=Math.max(0,Math.min(window.innerWidth-320,origLeft+e.clientX-startX))+'px';
    root.style.top =Math.max(0,Math.min(window.innerHeight-100,origTop +e.clientY-startY))+'px';
  }
  function endDrag(){
    if(!dragging)return;
    dragging=false;
    document.removeEventListener('mousemove',onMove);
    document.removeEventListener('mouseup',endDrag);
    const r=root.getBoundingClientRect();
    savedPos={right:Math.max(0,window.innerWidth-r.right),bottom:Math.max(0,window.innerHeight-r.bottom)};
    root.style.left='auto'; root.style.top='auto';
    root.style.right=savedPos.right+'px'; root.style.bottom=savedPos.bottom+'px';
    chrome.storage.local.set({ppc_pos:savedPos});
  }
  root.addEventListener('mousedown',startDrag);
}

// ── Boot ───────────────────────────────────────────────────────────────────
function isAiToolPage(){
  const h=location.href.toLowerCase();
  return ['claude.ai','chatgpt.com','chat.openai.com','gemini.google.com',
    'perplexity.ai','grok.x.ai','copilot.microsoft.com','replit.com',
    'bolt.new','v0.dev','cursor.sh','cursor.com','bard.google.com'].some(p=>h.includes(p));
}

function boot(){
  if(!isAiToolPage()) return; // only run on AI tools
  chrome.storage.local.get(['ppc_journal','ppc_panel_closed','ppc_pos'],res=>{
    if(res.ppc_journal)journal=res.ppc_journal;
    if(res.ppc_panel_closed)panelOpen=false;
    if(res.ppc_pos)savedPos=res.ppc_pos;
  });
  inject();

  // Staggered initial scans — catches messages that render after injection
  // and handles ChatGPT's SPA which may not have messages in DOM immediately
  scan();
  setTimeout(scan, 800);
  setTimeout(scan, 2000);
  setTimeout(scan, 4000);

  // Watch for new DOM nodes (new messages as they stream in)
  new MutationObserver(function(mutations) {
    var hasNewNodes = mutations.some(function(m) { return m.addedNodes.length > 0; });
    if (hasNewNodes) scan();
  }).observe(document.body,{childList:true,subtree:true});

  // Steady-state scan every 4 seconds as a safety net
  setInterval(scan, 4000);

  // SPA navigation watcher — re-scan when URL changes
  let lastUrl = location.href;
  setInterval(function() {
    if(location.href !== lastUrl){
      lastUrl = location.href;
      toolName = detectToolName();
      sels = SELECTORS[toolName] || {human:[], ai:[]};
      seenKeys = new Set();
      addLog('Now on ' + toolName, '#378ADD');
      userTyping = false;
      renderFull();
      // Staggered scans after navigation — gives SPA time to render messages
      setTimeout(scan, 500);
      setTimeout(scan, 1500);
      setTimeout(scan, 3500);
    }
  }, 800);
}

chrome.runtime.onMessage.addListener(function(msg, _, reply) {
  if (msg.type === 'GET_STATE') {
    // If turns is 0 but we have messages on the page, trigger a recovery scan
    if (turns.length === 0) {
      var hasMessages = document.querySelectorAll('[data-message-author-role]').length > 0
        || document.querySelectorAll('[data-testid="human-turn"]').length > 0;
      if (hasMessages) { scan(); setTimeout(scan, 500); }
    }
    reply({score, turns:turns.length, human:turns.filter(function(t){return t.author==='human';}).length, journal:journal.length, tool:toolName});
  }
  if (msg.type === 'TOGGLE_PANEL') {
    var p = document.getElementById('ppc-panel-root');
    if (p) {
      var show = p.style.display === 'none';
      p.style.display = show ? 'block' : 'none';
      panelOpen = show;
      if (show) renderFull();
    }
  }
  if (msg.type === 'FIRE_WRAP') fireCheck('wrap');
  if (msg.type === 'RESCAN') { seenKeys = new Set(); scan(); setTimeout(scan, 800); }
  return true;
});

if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot);
else boot();

// Expose rescan for the panel button
window.__ppcRescan = function() {
  seenKeys = new Set();
  scan();
  setTimeout(scan, 600);
  setTimeout(scan, 1500);
  addLog('Rescanning page...', '#378ADD');
};
})();
