/**
 * Patent PreCheck — eCO Auto-fill Content Script
 * Injected only on eco.copyright.gov / eservice.eco.loc.gov
 * 
 * SECURITY NOTE: Never fills payment fields, never clicks Submit/Pay buttons.
 * User must confirm each field before it is filled. User always clicks Submit.
 */

(function() {
'use strict';
if (window.__ppcEcoLoaded) return;
window.__ppcEcoLoaded = true;

// ── eCO field map ─────────────────────────────────────────────────────────
// Siebel eCO uses specific label text to identify fields.
// We find fields by their labels rather than fragile IDs.

var FIELD_MAP = {
  // Type of Work screen
  'Type of Work':           { key: 'f-worktype',   type: 'select' },
  'Title of This Work':     { key: 'f-title',       type: 'text' },
  'Title of Larger Work':   { key: null,             type: null },

  // Publication / Completion screen
  'Year of Completion':     { key: 'f-year',        type: 'text' },
  'Has this work been published?': { key: 'f-published', type: 'select' },
  'Date of Publication':    { key: 'f-pubdate',     type: 'text' },
  'Nation of Publication':  { key: 'f-pubnation',   type: 'select' },

  // Author screen
  'Author':                 { key: 'f-author',      type: 'text' },
  'Author\'s Pseudonym':    { key: null,             type: null },
  'Domicile':               { key: 'f-domicile',    type: 'text' },
  'Year of Birth':          { key: 'f-birthyear',   type: 'text' },
  'Nature of Authorship':   { key: 'f-authorship',  type: 'text' },
  'Work Made for Hire':     { key: 'f-forhire',     type: 'select' },

  // Claimant screen
  'Name':                   { key: 'f-claimant',    type: 'text' },
  'Street':                 { key: 'f-claimant-address', type: 'text' },

  // Correspondence screen
  'Email Address':          { key: null,             type: null }, // never auto-fill
};

// Work type mapping: our values → eCO dropdown values
var WORKTYPE_MAP = {
  'Literary Work': 'Literary Work',
  'Work of the Visual Arts': 'Work of the Visual Arts',
  'Work of the Performing Arts': 'Work of Performing Arts',
  'Sound Recording': 'Sound Recording',
  'Motion Picture / Audiovisual Work': 'Motion Picture/AV Work',
  'Single Serial Issue': 'Single Serial Issue',
};

// ── State ─────────────────────────────────────────────────────────────────
var formData = {};
var currentFieldIndex = 0;
var detectedFields = [];
var panelVisible = true;
var currentScreen = '';

// ── Load saved form data ──────────────────────────────────────────────────
chrome.storage.local.get(['ppc_cr_form'], function(res) {
  if (res.ppc_cr_form) {
    formData = res.ppc_cr_form;
  }
  init();
});

// ── Init ──────────────────────────────────────────────────────────────────
function init() {
  injectPanel();
  startWatcher();
}

// ── Page watcher — eCO is a SPA that updates without full reloads ─────────
function startWatcher() {
  // Watch for URL/view changes in the Siebel SPA
  var lastUrl = location.href;
  setInterval(function() {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      onPageChange();
    }
    // Also watch for Siebel view container changes
    detectCurrentScreen();
  }, 1000);

  // Initial scan after short delay for Siebel to render
  setTimeout(function() {
    detectCurrentScreen();
    onPageChange();
  }, 2000);
}

function onPageChange() {
  detectedFields = [];
  currentFieldIndex = 0;
  setTimeout(detectCurrentScreen, 1500);
}

// ── Screen detection ──────────────────────────────────────────────────────
function detectCurrentScreen() {
  var bodyText = document.body.innerText || '';

  // Detect which eCO screen we're on
  if (bodyText.includes('User Login') || bodyText.includes('User ID')) {
    currentScreen = 'login';
  } else if (bodyText.includes('Type of Work') && bodyText.includes('Register')) {
    currentScreen = 'type_of_work';
  } else if (bodyText.includes('Year of Completion') || bodyText.includes('Has this work been published')) {
    currentScreen = 'publication';
  } else if (bodyText.includes('Nature of Authorship') || (bodyText.includes('Author') && bodyText.includes('Domicile'))) {
    currentScreen = 'authorship';
  } else if (bodyText.includes('Copyright Claimant') || (bodyText.includes('Claimant') && bodyText.includes('Street'))) {
    currentScreen = 'claimant';
  } else if (bodyText.includes('Rights and Permissions') || bodyText.includes('Correspondence')) {
    currentScreen = 'correspondence';
  } else if (bodyText.includes('Certification') || bodyText.includes('Certify')) {
    currentScreen = 'certification';
  } else if (bodyText.includes('Shopping Cart') || bodyText.includes('Payment') || bodyText.includes('Credit Card')) {
    currentScreen = 'payment';
  } else if (bodyText.includes('Register a New Claim') || bodyText.includes('Home Page')) {
    currentScreen = 'home';
  } else {
    currentScreen = 'unknown';
  }

  updatePanel();
  scanFieldsForScreen();
}

// ── Find Siebel form fields ───────────────────────────────────────────────
// Siebel renders fields in a table-based layout where labels are in
// adjacent cells or divs. We find the label, then find the adjacent input.
function scanFieldsForScreen() {
  detectedFields = [];
  var screenFields = getScreenFields(currentScreen);
  if (!screenFields.length) return;

  screenFields.forEach(function(fieldDef) {
    var input = findFieldByLabel(fieldDef.label);
    if (input) {
      detectedFields.push({
        label:    fieldDef.label,
        input:    input,
        key:      fieldDef.key,
        value:    formData[fieldDef.key] || '',
        filled:   false,
      });
    }
  });

  if (detectedFields.length > 0) {
    currentFieldIndex = 0;
    updatePanel();
  }
}

function getScreenFields(screen) {
  var screens = {
    type_of_work: [
      { label: 'Type of Work',       key: 'f-worktype' },
      { label: 'Title of This Work', key: 'f-title'    },
    ],
    publication: [
      { label: 'Year of Completion', key: 'f-year'     },
    ],
    authorship: [
      { label: 'Author',             key: 'f-author'   },
      { label: 'Domicile',           key: 'f-domicile' },
      { label: 'Year of Birth',      key: 'f-birthyear'},
      { label: 'Nature of Authorship', key: 'f-authorship' },
    ],
    claimant: [
      { label: 'Name',               key: 'f-claimant' },
    ],
  };
  return screens[screen] || [];
}

// Find a Siebel input field by its label text
function findFieldByLabel(labelText) {
  // Siebel uses various patterns for labels
  // Method 1: Find span/td with exact label text, then find nearby input
  var allElements = document.querySelectorAll('span, td, label, div');
  var labelEl = null;

  for (var i = 0; i < allElements.length; i++) {
    var el = allElements[i];
    var text = (el.innerText || el.textContent || '').trim();
    if (text === labelText || text === labelText + ':' || text.startsWith(labelText)) {
      // Check it's actually a label (small element, no children with lots of text)
      if (el.children.length <= 2 && text.length < 60) {
        labelEl = el;
        break;
      }
    }
  }

  if (!labelEl) return null;

  // Find the nearest input/select/textarea
  // Try: next sibling, parent's next sibling, nearby in DOM
  var input = findNearestInput(labelEl);
  return input;
}

function findNearestInput(labelEl) {
  // Try parent row
  var parent = labelEl.parentElement;
  for (var depth = 0; depth < 4; depth++) {
    if (!parent) break;
    var inputs = parent.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]), select, textarea');
    if (inputs.length === 1) return inputs[0];
    if (inputs.length > 0) return inputs[0];
    parent = parent.parentElement;
  }

  // Try next sibling elements
  var sibling = labelEl.nextElementSibling;
  for (var i = 0; i < 5; i++) {
    if (!sibling) break;
    var inp = sibling.querySelector('input:not([type="hidden"]):not([type="submit"]):not([type="button"]), select, textarea');
    if (inp) return inp;
    sibling = sibling.nextElementSibling;
  }

  return null;
}

// ── Fill a single field ───────────────────────────────────────────────────
function fillField(fieldDef) {
  var input = fieldDef.input;
  var value = fieldDef.value;

  if (!input || !value) return false;

  // Map work type values
  if (fieldDef.key === 'f-worktype' && WORKTYPE_MAP[value]) {
    value = WORKTYPE_MAP[value];
  }

  // Highlight the field
  var origBorder = input.style.border;
  var origBg     = input.style.background;
  input.style.border     = '2px solid #0C447C';
  input.style.background = '#EBF4FF';
  input.scrollIntoView({ behavior: 'smooth', block: 'center' });

  // Set value based on field type
  var tag = input.tagName.toLowerCase();
  if (tag === 'select') {
    // Find matching option
    var opts = input.options;
    var matched = false;
    for (var i = 0; i < opts.length; i++) {
      if (opts[i].text.trim().toLowerCase().includes(value.toLowerCase()) ||
          opts[i].value.toLowerCase().includes(value.toLowerCase())) {
        input.selectedIndex = i;
        matched = true;
        break;
      }
    }
    if (!matched) {
      // Try first option that contains any word from value
      var words = value.toLowerCase().split(' ');
      for (var i = 0; i < opts.length; i++) {
        var optText = opts[i].text.toLowerCase();
        if (words.some(function(w) { return w.length > 3 && optText.includes(w); })) {
          input.selectedIndex = i;
          break;
        }
      }
    }
  } else {
    // Text / textarea
    input.value = value;
  }

  // Fire change/input events so Siebel's JS picks up the change
  ['focus','input','change','blur'].forEach(function(evtName) {
    try {
      input.dispatchEvent(new Event(evtName, { bubbles: true }));
    } catch(e) {}
  });

  // Mark as filled
  fieldDef.filled = true;

  // Restore highlight after delay
  setTimeout(function() {
    input.style.border     = origBorder || '';
    input.style.background = origBg     || '';
    // Add a subtle green tint to show it's been filled
    input.style.background = '#F0FDF4';
    input.style.border     = '1px solid #86EFAC';
  }, 1500);

  return true;
}

// ── Inject the Patent PreCheck panel ─────────────────────────────────────
function injectPanel() {
  if (document.getElementById('ppc-eco-root')) return;

  var root = document.createElement('div');
  root.id = 'ppc-eco-root';
  root.style.cssText = [
    'position:fixed',
    'top:80px',
    'right:16px',
    'width:300px',
    'z-index:2147483647',
    'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',
  ].join(';');

  document.body.appendChild(root);
  renderPanel();
}

// ── Render panel ──────────────────────────────────────────────────────────
function renderPanel() {
  var root = document.getElementById('ppc-eco-root');
  if (!root || !panelVisible) return;

  var hasData      = Object.keys(formData).length > 0;
  var screenLabel  = getScreenLabel(currentScreen);
  var fieldsDone   = detectedFields.filter(function(f) { return f.filled; }).length;
  var fieldsTotal  = detectedFields.length;
  var currentField = detectedFields[currentFieldIndex];
  var isPayment    = currentScreen === 'payment' || currentScreen === 'certification';
  var isLogin      = currentScreen === 'login';

  root.innerHTML = [
    '<div style="background:#fff;border-radius:14px;border:0.5px solid #e5e7eb;box-shadow:0 8px 32px rgba(0,0,0,.14);overflow:hidden">',

    // Header
    '<div style="background:#0C447C;padding:12px 14px;display:flex;align-items:center;gap:8px">',
      '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="7" fill="white" fill-opacity=".2"/><path d="M5 8l2 2 5-5" stroke="#fff" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      '<span style="font-size:13px;font-weight:700;color:#fff;flex:1">Patent PreCheck</span>',
      '<span style="font-size:10px;background:rgba(255,255,255,.2);color:#fff;padding:2px 8px;border-radius:10px">copyright.gov</span>',
      '<button onclick="window.__ppcEcoToggle()" style="background:none;border:none;color:rgba(255,255,255,.7);font-size:18px;cursor:pointer;line-height:1;padding:0 0 0 6px">×</button>',
    '</div>',

    // Screen indicator
    '<div style="padding:10px 14px;background:#f8faff;border-bottom:0.5px solid #f0f0f0;font-size:11px;color:#6b7280;display:flex;align-items:center;gap:6px">',
      '<div style="width:6px;height:6px;border-radius:50%;background:' + (isLogin ? '#EF9F27' : isPayment ? '#E24B4A' : '#1D9E75') + '"></div>',
      '<span>' + screenLabel + '</span>',
    '</div>',

    // Content
    getContentHTML(hasData, isLogin, isPayment, currentField, fieldsTotal, fieldsDone),

    '</div>',
  ].join('');

  wireEvents();
}

function getContentHTML(hasData, isLogin, isPayment, currentField, total, done) {
  // No data loaded
  if (!hasData) {
    return [
      '<div style="padding:16px;font-size:12px;color:#6b7280;line-height:1.65;text-align:center">',
        '<div style="font-size:32px;margin-bottom:8px">⚠️</div>',
        '<strong style="color:#374151;display:block;margin-bottom:6px">No application data found</strong>',
        'Complete the copyright wizard in Patent PreCheck first, then return here to auto-fill your forms.',
        '<br><br>',
        '<a href="' + chrome.runtime.getURL('dashboard/copyright.html') + '" target="_blank" ',
          'style="background:#0C447C;color:#fff;border:none;border-radius:8px;padding:8px 14px;font-size:12px;font-weight:600;cursor:pointer;text-decoration:none;display:inline-block">',
          'Open copyright wizard →',
        '</a>',
      '</div>',
    ].join('');
  }

  // Login screen
  if (isLogin) {
    return [
      '<div style="padding:14px">',
        '<div style="font-size:12px;color:#374151;line-height:1.65;margin-bottom:12px">',
          '✓ Application data loaded from your Patent PreCheck session.',
          '<br><br>',
          '<strong>Log in to your eCO account</strong> using your username and password. Patent PreCheck will then help you fill out each section automatically.',
        '</div>',
        '<div style="background:#EAF3DE;border-radius:8px;padding:10px 12px;font-size:11px;color:#276749">',
          'Don\'t have an account? <a href="https://eco.copyright.gov/eService_enu/" style="color:#0C447C;font-weight:600">Register free on copyright.gov</a>',
        '</div>',
      '</div>',
    ].join('');
  }

  // Payment screen — STOP
  if (isPayment) {
    return [
      '<div style="padding:14px">',
        '<div style="background:#FEF2F2;border-radius:8px;padding:12px;font-size:12px;color:#B91C1C;line-height:1.6;margin-bottom:10px">',
          '<strong>⛔ Patent PreCheck stops here</strong><br>',
          'Payment and final submission must be completed by you directly. We never handle payment or click Submit on your behalf.',
        '</div>',
        '<div style="font-size:12px;color:#374151;line-height:1.65">',
          '1. Review your application one more time<br>',
          '2. Enter your payment details<br>',
          '3. Click Pay / Submit yourself<br><br>',
          '<strong style="color:#1D9E75">Your registration is effective on the day you pay.</strong> Save your Service Request number afterward.',
        '</div>',
      '</div>',
    ].join('');
  }

  // No fields detected on this screen yet
  if (total === 0) {
    return [
      '<div style="padding:14px;font-size:12px;color:#6b7280;line-height:1.65;text-align:center">',
        '<div style="font-size:28px;margin-bottom:8px">🔍</div>',
        'Scanning this page for fields...',
        '<br><br>',
        'If fields don\'t appear, navigate to a form section on eCO and Patent PreCheck will detect them automatically.',
      '</div>',
    ].join('');
  }

  // Normal field-fill mode
  var allDone = done === total;

  if (allDone) {
    return [
      '<div style="padding:14px">',
        '<div style="background:#EAF3DE;border-radius:8px;padding:12px;font-size:12px;color:#276749;line-height:1.55;margin-bottom:10px;text-align:center">',
          '<strong>✓ All ' + total + ' fields filled on this screen</strong><br>',
          'Review each field, then click <strong>Save</strong> or <strong>Next</strong> on the eCO form to continue.',
        '</div>',
        '<div style="font-size:11px;color:#9ca3af;text-align:center">Patent PreCheck will detect the next screen automatically.</div>',
      '</div>',
    ].join('');
  }

  // Show current field to fill
  return [
    // Progress
    '<div style="padding:10px 14px 0">',
      '<div style="display:flex;justify-content:space-between;font-size:10px;color:#9ca3af;margin-bottom:5px">',
        '<span>Fields on this screen</span><span>' + done + ' of ' + total + ' filled</span>',
      '</div>',
      '<div style="height:4px;background:#f0f0f0;border-radius:2px;overflow:hidden;margin-bottom:10px">',
        '<div style="height:100%;width:' + Math.round((done/total)*100) + '%;background:#0C447C;border-radius:2px;transition:width .4s"></div>',
      '</div>',
    '</div>',

    // Current field card
    currentField ? [
      '<div style="margin:0 14px 14px;background:#f9fafb;border:1.5px solid #e5e7eb;border-radius:10px;overflow:hidden">',
        '<div style="padding:10px 12px 6px;font-size:9px;font-weight:700;color:#9ca3af;letter-spacing:.06em;text-transform:uppercase;display:flex;justify-content:space-between">',
          '<span>Next field to fill</span>',
          '<span>eCO label: ' + currentField.label + '</span>',
        '</div>',
        '<div style="padding:4px 12px 10px;font-size:13px;color:#111827;line-height:1.5;font-weight:500">' + (currentField.value || '<em style="color:#E24B4A;font-weight:400">No data — enter manually</em>') + '</div>',
        currentField.value ? [
          '<div style="padding:0 10px 10px;display:flex;gap:7px">',
            '<button id="ppc-eco-fill" style="flex:1;background:#0C447C;color:#fff;border:none;border-radius:7px;padding:8px;font-size:12px;font-weight:600;cursor:pointer">',
              'Fill this field →',
            '</button>',
            '<button id="ppc-eco-skip" style="background:#fff;border:1px solid #e5e7eb;border-radius:7px;padding:8px 10px;font-size:11px;color:#9ca3af;cursor:pointer">Skip</button>',
          '</div>',
        ].join('') : [
          '<div style="padding:0 10px 10px">',
            '<button id="ppc-eco-skip" style="width:100%;background:#fff;border:1px solid #e5e7eb;border-radius:7px;padding:8px;font-size:11px;color:#9ca3af;cursor:pointer">Skip — I\'ll fill manually</button>',
          '</div>',
        ].join(''),
      '</div>',
    ].join('') : '',

    // Fill all button
    '<div style="padding:0 14px 14px">',
      '<button id="ppc-eco-fillall" style="width:100%;background:#EBF4FF;color:#0C447C;border:1px solid #BFDBFE;border-radius:8px;padding:8px;font-size:11px;font-weight:600;cursor:pointer">',
        '⚡ Fill all ' + (total - done) + ' remaining fields at once',
      '</button>',
    '</div>',

    // Fields list
    '<div style="padding:0 14px 14px">',
      '<div style="font-size:10px;font-weight:700;color:#9ca3af;letter-spacing:.05em;text-transform:uppercase;margin-bottom:6px">All fields this screen</div>',
      detectedFields.map(function(f, idx) {
        return [
          '<div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:0.5px solid #f5f5f5;cursor:pointer" onclick="window.__ppcEcoJumpTo(' + idx + ')">',
            '<div style="width:16px;height:16px;border-radius:50%;border:1.5px solid ' + (f.filled ? '#1D9E75' : idx === currentFieldIndex ? '#0C447C' : '#e5e7eb') + ';background:' + (f.filled ? '#1D9E75' : 'transparent') + ';display:flex;align-items:center;justify-content:center;flex-shrink:0">',
              f.filled ? '<svg width="8" height="8" viewBox="0 0 8 8" fill="none"><path d="M1.5 4l2 2 3.5-3.5" stroke="#fff" stroke-width="1.3" stroke-linecap="round"/></svg>' : '',
            '</div>',
            '<span style="font-size:11px;color:' + (f.filled ? '#1D9E75' : '#374151') + ';flex:1">' + f.label + '</span>',
            '<span style="font-size:10px;color:#9ca3af;max-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + (f.value ? f.value.slice(0,20) : '—') + '</span>',
          '</div>',
        ].join('');
      }).join(''),
    '</div>',
  ].join('');
}

function getScreenLabel(screen) {
  var labels = {
    login:          'Login screen — please log in to continue',
    home:           'eCO Home — click "Register a New Claim"',
    type_of_work:   'Type of Work screen',
    publication:    'Publication / Completion screen',
    authorship:     'Author screen',
    claimant:       'Copyright Claimant screen',
    correspondence: 'Rights & Permissions screen',
    certification:  'Certification screen — review carefully',
    payment:        'Payment screen — complete this yourself',
    unknown:        'Scanning page...',
  };
  return labels[screen] || 'Scanning...';
}

// ── Wire panel button events ───────────────────────────────────────────────
function wireEvents() {
  var fillBtn    = document.getElementById('ppc-eco-fill');
  var skipBtn    = document.getElementById('ppc-eco-skip');
  var fillAllBtn = document.getElementById('ppc-eco-fillall');

  if (fillBtn) {
    fillBtn.addEventListener('click', function() {
      var field = detectedFields[currentFieldIndex];
      if (field) {
        var ok = fillField(field);
        if (ok) {
          currentFieldIndex = nextUnfilled(currentFieldIndex + 1);
        } else {
          currentFieldIndex = nextUnfilled(currentFieldIndex + 1);
        }
        renderPanel();
      }
    });
  }

  if (skipBtn) {
    skipBtn.addEventListener('click', function() {
      currentFieldIndex = nextUnfilled(currentFieldIndex + 1);
      renderPanel();
    });
  }

  if (fillAllBtn) {
    fillAllBtn.addEventListener('click', function() {
      detectedFields.forEach(function(f, idx) {
        if (!f.filled && f.value) {
          setTimeout(function() { fillField(f); }, idx * 300);
        }
      });
      setTimeout(function() {
        currentFieldIndex = detectedFields.length;
        renderPanel();
      }, detectedFields.length * 300 + 500);
    });
  }

  window.__ppcEcoToggle = function() {
    panelVisible = false;
    var root = document.getElementById('ppc-eco-root');
    if (root) {
      root.innerHTML = '<div style="background:#0C447C;border-radius:50%;width:44px;height:44px;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 3px 12px rgba(12,68,124,.35)" onclick="window.__ppcEcoShow()">' +
        '<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="9" stroke="#fff" stroke-width="1.5"/><path d="M6.5 10l2.5 2.5 5.5-5.5" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
        '</div>';
    }
  };

  window.__ppcEcoShow = function() {
    panelVisible = true;
    renderPanel();
  };

  window.__ppcEcoJumpTo = function(idx) {
    currentFieldIndex = idx;
    renderPanel();
  };
}

function nextUnfilled(startIdx) {
  for (var i = startIdx; i < detectedFields.length; i++) {
    if (!detectedFields[i].filled) return i;
  }
  return detectedFields.length; // all done
}

// Update panel without full re-render when possible
function updatePanel() {
  renderPanel();
}

})();
