// toolDetector.ts
// Detects which AI tool the user is on and returns the correct DOM selectors.
// Works universally — if the tool isn't recognised, falls back to generic
// heuristics (looks for large text blocks alternating roles).

import { ToolSignature } from './types';

export const KNOWN_TOOLS: ToolSignature[] = [
  {
    name:           'ChatGPT',
    urlPatterns:    ['chatgpt.com', 'chat.openai.com'],
    humanSelector:  '[data-message-author-role="user"]',
    aiSelector:     '[data-message-author-role="assistant"]',
    inputSelector:  '#prompt-textarea',
    submitSelector: '[data-testid="send-button"]',
  },
  {
    name:           'Claude',
    urlPatterns:    ['claude.ai'],
    humanSelector:  '[data-testid="human-turn"]',
    aiSelector:     '[data-testid="ai-turn"]',
    inputSelector:  '[contenteditable="true"].ProseMirror',
    submitSelector: '[aria-label="Send message"]',
  },
  {
    name:           'Gemini',
    urlPatterns:    ['gemini.google.com', 'bard.google.com'],
    humanSelector:  '.query-text',
    aiSelector:     '.response-content',
    inputSelector:  '.ql-editor',
    submitSelector: '[aria-label="Send message"]',
  },
  {
    name:           'Perplexity',
    urlPatterns:    ['perplexity.ai'],
    humanSelector:  '.user-message',
    aiSelector:     '.prose',
    inputSelector:  'textarea[placeholder]',
    submitSelector: 'button[aria-label="Submit"]',
  },
  {
    name:           'Copilot',
    urlPatterns:    ['copilot.microsoft.com', 'bing.com/chat'],
    humanSelector:  '.user-message',
    aiSelector:     '.ai-message',
    inputSelector:  '#searchbox',
    submitSelector: '#submit-button',
  },
  {
    name:           'Grok',
    urlPatterns:    ['grok.x.ai', 'x.com/i/grok'],
    humanSelector:  '[data-testid="userMessage"]',
    aiSelector:     '[data-testid="botMessage"]',
    inputSelector:  'textarea',
    submitSelector: '[data-testid="send-button"]',
  },
  {
    name:           'Replit',
    urlPatterns:    ['replit.com'],
    humanSelector:  '.human-message',
    aiSelector:     '.ai-message',
    inputSelector:  '.cm-content',
    submitSelector: '[data-cy="submit-btn"]',
  },
  {
    name:           'Bolt',
    urlPatterns:    ['bolt.new'],
    humanSelector:  '.user-message',
    aiSelector:     '.assistant-message',
    inputSelector:  'textarea',
    submitSelector: 'button[type="submit"]',
  },
  {
    name:           'v0',
    urlPatterns:    ['v0.dev'],
    humanSelector:  '.user-message',
    aiSelector:     '.assistant-message',
    inputSelector:  'textarea',
    submitSelector: 'button[type="submit"]',
  },
  {
    name:           'Cursor',
    urlPatterns:    ['cursor.sh', 'cursor.com'],
    humanSelector:  '.user-bubble',
    aiSelector:     '.assistant-bubble',
    inputSelector:  'textarea',
    submitSelector: 'button[data-testid="send"]',
  },
];

// Generic fallback for unknown tools
const GENERIC_SIGNATURE: ToolSignature = {
  name:           'AI Tool',
  urlPatterns:    [],
  humanSelector:  '[role="row"]:nth-child(odd), .user, .human, .question',
  aiSelector:     '[role="row"]:nth-child(even), .assistant, .ai, .answer, .response',
  inputSelector:  'textarea, [contenteditable="true"]',
  submitSelector: 'button[type="submit"], button[aria-label*="send" i], button[aria-label*="submit" i]',
};

export function detectTool(url: string = window.location.href): ToolSignature {
  const href = url.toLowerCase();
  for (const tool of KNOWN_TOOLS) {
    if (tool.urlPatterns.some(p => href.includes(p))) {
      return tool;
    }
  }
  return GENERIC_SIGNATURE;
}

export function getToolName(url: string = window.location.href): string {
  return detectTool(url).name;
}
