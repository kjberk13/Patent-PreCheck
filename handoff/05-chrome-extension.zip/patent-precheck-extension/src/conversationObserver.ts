// conversationObserver.ts
// Watches the page DOM for new conversation turns using MutationObserver.
// Works on any detected tool. Falls back to polling for tools that
// update the DOM in ways that don't trigger standard mutation events.

import { ConversationTurn, TurnAuthor } from './types';
import { detectTool, getToolName } from './toolDetector';

type TurnCallback = (turn: ConversationTurn) => void;

export class ConversationObserver {
  private observer:      MutationObserver | null = null;
  private pollTimer:     ReturnType<typeof setInterval> | null = null;
  private seenElements:  Set<Element> = new Set();
  private onTurn:        TurnCallback;
  private tool           = detectTool();
  private toolName       = getToolName();

  constructor(onTurnCaptured: TurnCallback) {
    this.onTurn = onTurnCaptured;
  }

  start(): void {
    this.scanExisting();
    this.startObserver();
    // Fallback poll every 3s for tools that batch DOM updates
    this.pollTimer = setInterval(() => this.scanExisting(), 3000);
  }

  stop(): void {
    this.observer?.disconnect();
    if (this.pollTimer) clearInterval(this.pollTimer);
  }

  private startObserver(): void {
    this.observer = new MutationObserver(() => {
      this.scanExisting();
    });
    this.observer.observe(document.body, {
      childList:  true,
      subtree:    true,
      attributes: false,
    });
  }

  private scanExisting(): void {
    this.scanSelector(this.tool.humanSelector, 'human');
    this.scanSelector(this.tool.aiSelector,    'ai');
  }

  private scanSelector(selector: string, author: TurnAuthor): void {
    let elements: NodeListOf<Element>;
    try {
      elements = document.querySelectorAll(selector);
    } catch {
      return; // invalid selector on some pages — skip
    }

    elements.forEach(el => {
      if (this.seenElements.has(el)) return;
      const text = el.textContent?.trim() ?? '';
      if (text.length < 10) return; // skip empty / loading states

      this.seenElements.add(el);
      const turn = this.buildTurn(el, author, text);
      this.onTurn(turn);
    });
  }

  private buildTurn(el: Element, author: TurnAuthor, text: string): ConversationTurn {
    return {
      id:        `turn-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      author,
      text:      text.slice(0, 8000), // cap at 8k chars
      timestamp: Date.now(),
      url:       window.location.href,
      tool:      this.toolName,
      flags:     [],
    };
  }

  // Re-initialise when the user navigates to a new conversation
  // (SPAs don't reload the page between chats)
  reinitialize(): void {
    this.seenElements.clear();
    this.tool     = detectTool();
    this.toolName = getToolName();
    this.scanExisting();
  }
}
