export type TurnAuthor = 'human' | 'ai';
export type UrgencyLevel = 'critical' | 'high' | 'moderate' | 'low';
export type ComplianceCategory = 1 | 2 | 3 | 4;

export interface ConversationTurn {
  id: string; author: TurnAuthor; text: string; timestamp: number;
  url: string; tool: string; turnScore?: number; flags: string[];
}

export interface PatentPreCheckScore {
  overall: number; conception: number; eligibility: number;
  documentation: number; lastUpdated: number;
  turnCount: number; humanTurns: number; aiTurns: number;
}

export interface HygieneCheck {
  id: string; trigger: string; category: ComplianceCategory;
  title: string; question: string; placeholder: string;
  guidance: string; scoreGain: number; urgency: UrgencyLevel;
  canSnooze: boolean; canSkip: boolean;
  context: Record<string, string>; firedAt: number;
}

export interface JournalEntry {
  id: string; timestamp: number; category: ComplianceCategory;
  trigger: string; answer: string; scoreGain: number;
  turnId?: string; url: string; tool: string;
}

export interface ToolSignature {
  name: string; urlPatterns: string[];
  humanSelector: string; aiSelector: string;
  inputSelector: string; submitSelector: string;
}
