// hygieneEngine.ts
// Determines when to fire hygiene checks based on what's happening
// in the conversation. Same four-category compliance framework as the
// VS Code extension, adapted for browser conversation context.

import { ConversationTurn, HygieneCheck, UrgencyLevel } from './types';

let checkQueue:    HygieneCheck[]    = [];
let lastCheckAt:   number            = 0;
let checksThisSession: number        = 0;
const SESSION_MAX  = 5;   // max checks per browsing session
const MIN_GAP_MS   = 10 * 60 * 1000; // 10 min min gap between checks

// ── Check definitions ────────────────────────────────────────────────────────

const CHECKS = {

  conception_moment: (): HygieneCheck => ({
    id:          `hygiene-conception-${Date.now()}`,
    trigger:     'conception_moment',
    category:    1,
    urgency:     'critical',
    title:       'Conception moment detected',
    question:    'That looks like a key insight — describe the specific mechanism you just figured out in your own words. Not the goal, the mechanism itself.',
    placeholder: 'e.g. The key mechanism is that inter-arrival variance is a better burst signal than mean rate because variance captures the statistical spread that moving averages structurally discard...',
    guidance:    'USPTO 2025: "A definite and permanent idea of the complete and operative invention." Capturing this now creates your priority date evidence.',
    scoreGain:   15,
    canSnooze:   false,
    canSkip:     false,
    context:     {},
    firedAt:     Date.now(),
  }),

  ai_parameter_accepted: (value: string): HygieneCheck => ({
    id:          `hygiene-param-${Date.now()}`,
    trigger:     'ai_parameter_accepted',
    category:    3,
    urgency:     'high',
    title:       'AI suggested a key value — did it come from your data?',
    question:    `The AI suggested "${value}" as a key number in your idea. Did that come from your own research or measurements?`,
    placeholder: 'e.g. I measured this from 90 days of production traffic — the 90th percentile inter-arrival time during non-burst periods was around that value...',
    guidance:    'Holland & Knight: AI-suggested parameters accepted without validation are §101 risk under Recentive Analytics v. Fox Corp (2025).',
    scoreGain:   10,
    canSnooze:   true,
    canSkip:     false,
    context:     { value },
    firedAt:     Date.now(),
  }),

  strong_human_turn: (): HygieneCheck => ({
    id:          `hygiene-human-${Date.now()}`,
    trigger:     'strong_human_turn',
    category:    1,
    urgency:     'moderate',
    title:       'You articulated something specific',
    question:    'That message showed clear original thinking. Before you move on — is there anything else about this idea that came from your domain knowledge or experience that you haven't said yet?',
    placeholder: 'e.g. My insight here also draws from the March incident post-mortem where we saw burst buildup 40 minutes before detection — the AI has no access to that operational history...',
    guidance:    'JD Supra: "Documentation showing the human identified the problem before AI use." Capturing context while it\'s fresh creates stronger evidence.',
    scoreGain:   8,
    canSnooze:   true,
    canSkip:     true,
    context:     {},
    firedAt:     Date.now(),
  }),

  session_wrap: (): HygieneCheck => ({
    id:          `hygiene-wrap-${Date.now()}`,
    trigger:     'session_wrap',
    category:    1,
    urgency:     'high',
    title:       'Before you close this tab',
    question:    'What did you conceive in this session that was not in any AI response? What did you know from your own experience that shaped what the AI produced?',
    placeholder: 'e.g. The queue-depth weighting factor was entirely mine — no AI suggested it. I saw the failure mode in our incident logs from March where pure variance detection missed a 40-minute backlog buildup...',
    guidance:    'Morgan Lewis: Document "what the inventor contributed independently of AI output." Session-end is the optimal moment — detail is still fresh.',
    scoreGain:   12,
    canSnooze:   false,
    canSkip:     false,
    context:     {},
    firedAt:     Date.now(),
  }),

  high_ai_ratio: (): HygieneCheck => ({
    id:          `hygiene-ratio-${Date.now()}`,
    trigger:     'high_ai_ratio',
    category:    3,
    urgency:     'high',
    title:       'Most of this conversation is AI output',
    question:    'A large share of this conversation is AI responses. What specific constraints, requirements, or domain knowledge were you using to direct and evaluate what the AI produced?',
    placeholder: 'e.g. Although much of the implementation detail came from the AI, every suggestion was filtered through three requirements I set: variance-based detection (my insight), queue-depth weighting (my invention), and 200ms base window (my measurement)...',
    guidance:    'Recentive Analytics v. Fox Corp (2025): "Generic AI applied to a new environment" is §101 ineligible. Show the human provided specific technical direction.',
    scoreGain:   12,
    canSnooze:   true,
    canSkip:     false,
    context:     {},
    firedAt:     Date.now(),
  }),

};

// ── Trigger logic ─────────────────────────────────────────────────────────────

export function evaluateTurn(
  turn:          ConversationTurn,
  allTurns:      ConversationTurn[],
  isConception:  boolean,
): HygieneCheck | null {

  if (!canFireCheck()) return null;

  // Conception moment — highest priority, always fires
  if (isConception && turn.author === 'human') {
    return enqueue(CHECKS.conception_moment());
  }

  // AI suggested a specific numeric value
  if (turn.author === 'ai') {
    const numMatch = turn.text.match(/\b(\d+(?:\.\d+)?)\s*(?:ms|seconds?|percent|%|threshold|value)\b/i);
    if (numMatch) {
      return enqueue(CHECKS.ai_parameter_accepted(numMatch[1]));
    }
  }

  // Strong human turn (score >= 70) — fire occasionally, not every time
  if (turn.author === 'human' && (turn.turnScore ?? 0) >= 70) {
    if (Math.random() < 0.4) { // 40% chance to avoid over-firing
      return enqueue(CHECKS.strong_human_turn());
    }
  }

  // High AI ratio warning (>65% AI turns)
  const aiCount    = allTurns.filter(t => t.author === 'ai').length;
  const totalCount = allTurns.length;
  if (totalCount >= 6 && (aiCount / totalCount) > 0.65) {
    return enqueue(CHECKS.high_ai_ratio());
  }

  return null;
}

export function getSessionWrapCheck(): HygieneCheck {
  return CHECKS.session_wrap();
}

export function getPendingChecks(): HygieneCheck[] {
  return [...checkQueue];
}

export function dismissCheck(id: string): void {
  checkQueue = checkQueue.filter(c => c.id !== id);
}

export function snoozeCheck(id: string): void {
  const check = checkQueue.find(c => c.id === id);
  if (check) {
    // Re-queue after 30 minutes by updating firedAt
    check.firedAt = Date.now() + 30 * 60 * 1000;
  }
}

function enqueue(check: HygieneCheck): HygieneCheck {
  checkQueue.push(check);
  lastCheckAt = Date.now();
  checksThisSession++;
  return check;
}

function canFireCheck(): boolean {
  if (checksThisSession >= SESSION_MAX)                     return false;
  if (Date.now() - lastCheckAt < MIN_GAP_MS)               return false;
  return true;
}

export function resetSession(): void {
  checkQueue         = [];
  checksThisSession  = 0;
  lastCheckAt        = 0;
}
