// scoreEngine.ts
// Client-side scoring layer for the Patent PreCheck Chrome extension.
// Runs a lightweight local estimate so the panel updates instantly,
// then syncs with the server-side AI Patentability Algorithm for the
// authoritative Patent PreCheck Score.

import { ConversationTurn, PatentPreCheckScore } from './types';

// ── Conception signal keywords ────────────────────────────────────────────────
const CONCEPTION_SIGNALS = [
  /key insight/i, /i realized/i, /i figured out/i, /the mechanism is/i,
  /my approach/i, /my idea/i, /what i found/i, /i measured/i, /i tested/i,
  /unlike existing/i, /the problem with/i, /specifically because/i,
  /what makes this different/i, /the reason i/i, /i noticed/i,
  /our data shows/i, /from profiling/i, /i discovered/i,
];

const DOMAIN_SIGNALS = [
  /\d+\s*(ms|seconds|percent|%|kb|mb|gb|hz|rpm|db)/i,
  /production\s+data/i, /traffic\s+logs/i, /our\s+system/i,
  /empirically/i, /we\s+measured/i, /performance\s+test/i,
  /benchmar/i, /threshold/i, /latency/i, /throughput/i,
];

const WEAK_SIGNALS = [
  /let'?s use/i, /we should use/i, /use\s+\w+\s+for/i,
  /just use/i, /can we use/i, /something like/i,
];

// ── Per-turn scoring ─────────────────────────────────────────────────────────

export function scoreTurn(turn: ConversationTurn): number {
  if (turn.author === 'ai') return 0;

  const t   = turn.text;
  let score = 30; // base for any human contribution

  // Conception language
  const conceptionHits = CONCEPTION_SIGNALS.filter(r => r.test(t)).length;
  score += Math.min(conceptionHits * 15, 35);

  // Domain-specific data or measurements
  const domainHits = DOMAIN_SIGNALS.filter(r => r.test(t)).length;
  score += Math.min(domainHits * 10, 25);

  // Length is a weak proxy for detail
  if (t.length > 200)  score += 5;
  if (t.length > 500)  score += 5;
  if (t.length > 1000) score += 5;

  // Weaken for generic/vague language
  const weakHits = WEAK_SIGNALS.filter(r => r.test(t)).length;
  score -= weakHits * 12;

  // Contains a question only — minimal value
  if (t.endsWith('?') && t.split(' ').length < 15) score -= 20;

  return Math.max(0, Math.min(100, Math.round(score)));
}

export function detectConceptionMoment(turn: ConversationTurn): boolean {
  if (turn.author !== 'human') return false;
  const hits = CONCEPTION_SIGNALS.filter(r => r.test(turn.text)).length;
  return hits >= 2 || (hits >= 1 && DOMAIN_SIGNALS.some(r => r.test(turn.text)));
}

// ── Composite Patent PreCheck Score ─────────────────────────────────────────
// This is the local estimate. Server-side AI Patentability Algorithm
// returns the authoritative score — this keeps the panel responsive.

export function computeLocalScore(turns: ConversationTurn[]): PatentPreCheckScore {
  const humanTurns = turns.filter(t => t.author === 'human');
  const aiTurns    = turns.filter(t => t.author === 'ai');

  if (humanTurns.length === 0) {
    return {
      overall: 0, conception: 0, eligibility: 0, documentation: 0,
      lastUpdated: Date.now(), turnCount: 0, humanTurns: 0, aiTurns: 0,
    };
  }

  // Score each human turn
  const turnScores = humanTurns.map(scoreTurn);
  const avgTurnScore = turnScores.reduce((a, b) => a + b, 0) / turnScores.length;

  // Conception strength (50% weight)
  const topThree       = [...turnScores].sort((a, b) => b - a).slice(0, 3);
  const conceptionScore = Math.round(topThree.reduce((a, b) => a + b, 0) / topThree.length);

  // §101 eligibility estimate (35% weight)
  // Better when human turns show specificity, worse when AI ratio is high
  const humanRatio   = humanTurns.length / Math.max(turns.length, 1);
  const specificityBonus = CONCEPTION_SIGNALS.filter(r =>
    humanTurns.some(t => r.test(t.text))
  ).length * 3;
  const eligibility = Math.min(100, Math.round(
    40 + (avgTurnScore * 0.3) + (humanRatio * 20) + specificityBonus
  ));

  // Documentation quality (15% weight) — starts low, grows with journal entries
  // Server will fill this in with actual journal data
  const documentation = 10;

  // Weighted composite
  const overall = Math.round(
    conceptionScore * 0.50 +
    eligibility     * 0.35 +
    documentation   * 0.15
  );

  return {
    overall:       Math.min(100, overall),
    conception:    conceptionScore,
    eligibility,
    documentation,
    lastUpdated:   Date.now(),
    turnCount:     turns.length,
    humanTurns:    humanTurns.length,
    aiTurns:       aiTurns.length,
  };
}
